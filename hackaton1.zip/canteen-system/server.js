const express = require('express');
const cors = require('cors');
const path = require('path');
const fs = require('fs');
const os = require('os');
const QRCode = require('qrcode');

const app = express();
const PORT = process.env.PORT || 3000;
const DB_FILE = path.join(__dirname, 'data', 'canteen_db.json');

// Helper to get local Wi-Fi / Ethernet IPv4 address
function getLocalIpAddress() {
  const interfaces = os.networkInterfaces();
  for (const name of Object.keys(interfaces)) {
    for (const iface of interfaces[name]) {
      if (iface.family === 'IPv4' && !iface.internal) {
        return iface.address;
      }
    }
  }
  return 'localhost';
}

// Middleware
app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, 'public')));

// Default Seed Data
function getInitialSeedData() {
  return {
    admin: {
      id: 'ADM-001',
      fullName: 'System Administrator',
      email: 'admin@admin.com',
      password: 'admin',
      role: 'admin',
      mustChangePassword: true,
      updatedAt: new Date().toISOString()
    },
    students: [
      {
        id: '9876543210', // User ID is the Phone Number
        fullName: 'Rahul Sharma',
        email: 'student@canteen.local',
        phone: '9876543210',
        password: 'student123',
        role: 'student',
        walletBalance: 150,
        createdAt: new Date().toISOString()
      }
    ],
    menu: [
      {
        id: 'ITEM-1',
        name: 'Masala Dosa',
        category: 'South Indian',
        price: 60,
        stock: 25,
        description: 'Crispy golden crepe filled with spiced potato mash, served with piping hot sambar & coconut chutney.',
        icon: '🥞',
        badge: 'Popular'
      },
      {
        id: 'ITEM-2',
        name: 'Veg Thali Meal',
        category: 'Main Course',
        price: 90,
        stock: 30,
        description: 'Nutritious lunch platter with 2 rotis, dal tadka, paneer sabzi, steamed basmati rice, salad & dessert.',
        icon: '🍱',
        badge: 'Chef Special'
      },
      {
        id: 'ITEM-3',
        name: 'Crispy Samosa (2 pcs)',
        category: 'Snacks',
        price: 30,
        stock: 50,
        description: 'Flaky pastry cones stuffed with seasoned potato and green peas, served with mint & tamarind chutney.',
        icon: '🥟',
        badge: 'Quick Bite'
      },
      {
        id: 'ITEM-4',
        name: 'Cold Coffee',
        category: 'Beverages',
        price: 40,
        stock: 40,
        description: 'Chilled espresso blend with whole milk, chocolate drizzle, and creamy vanilla ice cream.',
        icon: '☕',
        badge: 'Chilled'
      },
      {
        id: 'ITEM-5',
        name: 'Paneer Frankie Roll',
        category: 'Snacks',
        price: 70,
        stock: 20,
        description: 'Warm flaky paratha roll loaded with marinated cottage cheese cubes, pickled onions, and zesty sauce.',
        icon: '🌯',
        badge: 'Spicy'
      }
    ],
    orders: [],
    transactions: [
      {
        id: 'TXN-INIT-001',
        userId: '9876543210',
        userName: 'Rahul Sharma',
        type: 'CREDIT',
        amount: 150,
        balanceAfter: 150,
        description: 'Initial Account Welcome Credit',
        referenceId: 'SYS-WELCOME',
        timestamp: new Date().toISOString()
      }
    ],
    auditLogs: [
      {
        id: 'AUDIT-INIT-001',
        action: 'SYSTEM_INITIALIZED',
        details: 'Canteen system initialized with single admin account (admin@admin.com) and pre-seeded student (User ID: 9876543210).',
        actor: 'SYSTEM',
        timestamp: new Date().toISOString()
      }
    ],
    hostelMeals: []
  };
}

let db = getInitialSeedData();

// Load or Save DB
function initDB() {
  try {
    if (!fs.existsSync(path.join(__dirname, 'data'))) {
      fs.mkdirSync(path.join(__dirname, 'data'), { recursive: true });
    }
    if (fs.existsSync(DB_FILE)) {
      const data = fs.readFileSync(DB_FILE, 'utf8');
      db = JSON.parse(data);
      // Ensure schema matches new requirements
      if (!db.admin) {
        db = getInitialSeedData();
        saveDB();
      }
      db.hostelMeals = db.hostelMeals || [];
      // Ensure studentType is populated for all students
      if (Array.isArray(db.students)) {
        db.students.forEach(s => {
          if (!s.studentType) {
            // Rahul Sharma and Joel default to hosteler for easy testing
            if (s.id === '9876543210' || s.phone === '9876543210' || s.id === '7736410760') {
              s.studentType = 'hosteler';
            } else {
              s.studentType = 'dayscholar';
            }
          }
        });
      }
      console.log('✔ Loaded database from data/canteen_db.json');
    } else {
      saveDB();
      console.log('✔ Initialized new database with pre-seeded test data');
    }
  } catch (err) {
    console.error('Error initializing database, using fresh seed:', err.message);
    db = getInitialSeedData();
    saveDB();
  }
}

function saveDB() {
  try {
    fs.writeFileSync(DB_FILE, JSON.stringify(db, null, 2), 'utf8');
  } catch (err) {
    console.error('Error saving database:', err.message);
  }
}

initDB();

function addAudit(action, details, actor = 'SYSTEM') {
  const log = {
    id: `AUDIT-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
    action,
    details,
    actor,
    timestamp: new Date().toISOString()
  };
  db.auditLogs.unshift(log);
  if (db.auditLogs.length > 500) db.auditLogs.pop();
}

// -------------------------------------------------------------
// HTML Page Routes
// -------------------------------------------------------------
app.get('/student', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'student.html'));
});

app.get('/admin', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'admin.html'));
});

// -------------------------------------------------------------
// REST API Endpoints
// -------------------------------------------------------------

// 1. POST /api/auth/login
app.post('/api/auth/login', (req, res) => {
  try {
    const { email, password, role } = req.body;
    if (!email || !password) {
      return res.status(400).json({ success: false, message: 'Email/Phone and password are required.' });
    }

    const cleanInput = email.trim().toLowerCase();
    const cleanPassword = password.trim();

    // Check Admin login (Single account: admin@admin.com)
    if (cleanInput === 'admin@admin.com' || role === 'admin') {
      if (cleanInput === db.admin.email.toLowerCase() && cleanPassword === db.admin.password) {
        const { password: _, ...safeAdmin } = db.admin;
        return res.json({
          success: true,
          message: 'Admin signed in successfully.',
          user: safeAdmin,
          role: 'admin',
          mustChangePassword: db.admin.mustChangePassword === true,
          token: `token-admin-${Date.now()}`
        });
      } else {
        return res.status(401).json({ success: false, message: 'Invalid admin credentials.' });
      }
    }

    // Student login (User ID is phone number, or email)
    const student = db.students.find(s => 
      (s.id === cleanInput || s.phone === cleanInput || s.email.toLowerCase() === cleanInput) && 
      s.password === cleanPassword
    );

    if (!student) {
      return res.status(401).json({ success: false, message: 'Invalid User ID/Phone or Password.' });
    }

    const { password: _, ...safeStudent } = student;
    return res.json({
      success: true,
      message: 'Student logged in successfully.',
      user: safeStudent,
      role: 'student',
      token: `token-${student.id}`
    });
  } catch (err) {
    return res.status(500).json({ success: false, message: 'Server error during login', error: err.message });
  }
});

// POST /api/auth/register (Student Registration)
app.post('/api/auth/register', (req, res) => {
  try {
    const { fullName, email, phone, password, studentType } = req.body;
    if (!fullName || !email || !phone || !password) {
      return res.status(400).json({ success: false, message: 'All fields (Full Name, Email, Phone Number, Password) are required.' });
    }

    const cleanPhone = phone.trim().replace(/\D/g, ''); // Extract digits
    if (cleanPhone.length < 10) {
      return res.status(400).json({ success: false, message: 'Please provide a valid 10-digit mobile phone number.' });
    }

    const cleanEmail = email.trim().toLowerCase();
    const validStudentType = (studentType === 'hosteler') ? 'hosteler' : 'dayscholar';

    // In student portal: User ID MUST be their Phone Number
    const existing = db.students.find(s => s.id === cleanPhone || s.phone === cleanPhone || s.email.toLowerCase() === cleanEmail);
    if (existing) {
      return res.status(400).json({ success: false, message: `An account with Phone / User ID "${cleanPhone}" or email already exists.` });
    }

    const newStudent = {
      id: cleanPhone, // Phone Number IS the User ID
      fullName: fullName.trim(),
      email: cleanEmail,
      phone: cleanPhone,
      password: password.trim(),
      role: 'student',
      studentType: validStudentType,
      walletBalance: 0,
      createdAt: new Date().toISOString()
    };

    db.students.push(newStudent);
    addAudit('STUDENT_REGISTERED', `New student registered: ${newStudent.fullName} (${validStudentType}) with User ID (Phone): ${newStudent.id}`, newStudent.id);
    saveDB();

    const { password: _, ...safeStudent } = newStudent;
    return res.status(201).json({
      success: true,
      message: `Student account created successfully as a ${validStudentType === 'hosteler' ? 'Hosteler' : 'Day Scholar'}! Your User ID is your Phone Number.`,
      user: safeStudent,
      token: `token-${newStudent.id}`
    });
  } catch (err) {
    return res.status(500).json({ success: false, message: 'Server error during registration', error: err.message });
  }
});

// POST /api/admin/change-password (Admin Mandatory Password Change)
app.post('/api/admin/change-password', (req, res) => {
  try {
    const { currentPassword, newPassword } = req.body;
    if (!currentPassword || !newPassword) {
      return res.status(400).json({ success: false, message: 'Current password and new password are required.' });
    }

    if (currentPassword !== db.admin.password) {
      return res.status(401).json({ success: false, message: 'Current password is incorrect.' });
    }

    if (newPassword.trim().length < 4) {
      return res.status(400).json({ success: false, message: 'New password must be at least 4 characters.' });
    }

    db.admin.password = newPassword.trim();
    db.admin.mustChangePassword = false;
    db.admin.updatedAt = new Date().toISOString();

    addAudit('ADMIN_PASSWORD_CHANGED', 'Administrator updated their master password.', db.admin.id);
    saveDB();

    const { password: _, ...safeAdmin } = db.admin;
    return res.json({
      success: true,
      message: 'Password updated successfully! Welcome to the Admin Console.',
      user: safeAdmin
    });
  } catch (err) {
    return res.status(500).json({ success: false, message: 'Server error changing password', error: err.message });
  }
});

// GET /api/auth/me
app.get('/api/auth/me', (req, res) => {
  const userId = req.headers['x-user-id'] || req.query.userId;
  if (!userId) {
    return res.status(400).json({ success: false, message: 'User ID required' });
  }

  if (userId === db.admin.id || userId === 'admin@admin.com') {
    const { password: _, ...safeAdmin } = db.admin;
    return res.json({ success: true, user: safeAdmin });
  }

  const student = db.students.find(s => s.id === userId || s.phone === userId);
  if (!student) {
    return res.status(404).json({ success: false, message: 'Student not found' });
  }

  const { password: _, ...safeStudent } = student;
  return res.json({ success: true, user: safeStudent });
});

// 2. DIRECT MONEY CREDITING SYSTEM (Admin types User ID & credits money directly)
// POST /api/admin/credit-wallet
app.post('/api/admin/credit-wallet', (req, res) => {
  try {
    const { userId, amount, note, adminEmail } = req.body;
    if (!userId || !amount) {
      return res.status(400).json({ success: false, message: 'Student User ID (Phone Number) and credit amount are required.' });
    }

    const cleanUserId = userId.toString().trim().replace(/\D/g, '') || userId.toString().trim();
    const parsedAmount = Number(amount);

    if (isNaN(parsedAmount) || parsedAmount <= 0) {
      return res.status(400).json({ success: false, message: 'Please enter a valid positive amount in INR (₹).' });
    }

    // Find student by User ID (which is their phone number)
    const student = db.students.find(s => s.id === cleanUserId || s.phone === cleanUserId);
    if (!student) {
      return res.status(404).json({
        success: false,
        message: `Student with User ID / Phone "${cleanUserId}" not found in database. Please check the number.`
      });
    }

    // Credit money directly to student's wallet balance
    student.walletBalance = Number((student.walletBalance + parsedAmount).toFixed(2));

    // Log credit transaction
    const txnId = `TXN-${Date.now()}-${Math.floor(Math.random() * 900 + 100)}`;
    const txn = {
      id: txnId,
      userId: student.id,
      userName: student.fullName,
      type: 'CREDIT',
      amount: parsedAmount,
      balanceAfter: student.walletBalance,
      description: note ? `Cash Deposit: ${note}` : 'Direct Cash Deposit at Canteen Counter',
      referenceId: `DEP-${cleanUserId.slice(-4)}-${Date.now().toString().slice(-4)}`,
      timestamp: new Date().toISOString()
    };
    db.transactions.unshift(txn);

    // Add Audit Log
    addAudit(
      'DIRECT_CREDIT',
      `Admin credited ₹${parsedAmount} directly to Student ${student.fullName} (User ID: ${student.id}). New Balance: ₹${student.walletBalance}.`,
      adminEmail || 'admin@admin.com'
    );

    saveDB();

    const { password: _, ...safeStudent } = student;
    return res.json({
      success: true,
      message: `🎉 Successfully credited ₹${parsedAmount} directly into ${student.fullName}'s wallet!`,
      student: safeStudent,
      creditedAmount: parsedAmount,
      newBalance: student.walletBalance,
      transaction: txn
    });
  } catch (err) {
    return res.status(500).json({ success: false, message: 'Server error during direct credit', error: err.message });
  }
});

// GET /api/admin/lookup-student (Instant search while cashier types phone / User ID)
app.get('/api/admin/lookup-student', (req, res) => {
  const { userId } = req.query;
  if (!userId) {
    return res.status(400).json({ success: false, message: 'User ID required' });
  }

  const cleanUserId = userId.toString().trim().replace(/\D/g, '') || userId.toString().trim();
  const student = db.students.find(s => s.id === cleanUserId || s.phone === cleanUserId);

  if (!student) {
    return res.status(404).json({ success: false, message: 'No student found with this User ID / Phone.' });
  }

  const { password: _, ...safeStudent } = student;
  return res.json({ success: true, student: safeStudent });
});

// 3. GET /api/menu & POST /api/orders/create
app.get('/api/menu', (req, res) => {
  return res.json({ success: true, menu: db.menu });
});

app.post('/api/orders/create', async (req, res) => {
  try {
    const { userId, items } = req.body;
    if (!userId || !Array.isArray(items) || items.length === 0) {
      return res.status(400).json({ success: false, message: 'Invalid order request. User ID and items are required.' });
    }

    const cleanUserId = userId.toString().trim();
    const student = db.students.find(s => s.id === cleanUserId || s.phone === cleanUserId);
    if (!student) {
      return res.status(404).json({ success: false, message: 'Student account not found.' });
    }

    // Calculate total and check stock
    let totalAmount = 0;
    const orderItems = [];

    for (const itemRequest of items) {
      const { itemId, quantity } = itemRequest;
      const qty = parseInt(quantity, 10);
      if (!qty || qty <= 0) {
        return res.status(400).json({ success: false, message: 'Item quantity must be greater than zero.' });
      }

      const menuItem = db.menu.find(m => m.id === itemId);
      if (!menuItem) {
        return res.status(404).json({ success: false, message: `Menu item ${itemId} not found.` });
      }

      if (menuItem.stock < qty) {
        return res.status(400).json({
          success: false,
          message: `Insufficient stock for "${menuItem.name}". Available: ${menuItem.stock}, Requested: ${qty}.`
        });
      }

      const subtotal = menuItem.price * qty;
      totalAmount += subtotal;
      orderItems.push({
        itemId: menuItem.id,
        name: menuItem.name,
        price: menuItem.price,
        quantity: qty,
        subtotal: subtotal,
        icon: menuItem.icon
      });
    }

    // Check student wallet balance
    if (student.walletBalance < totalAmount) {
      const shortfall = Number((totalAmount - student.walletBalance).toFixed(2));
      return res.status(400).json({
        success: false,
        insufficientFunds: true,
        message: `Insufficient wallet balance! Current balance: ₹${student.walletBalance}, Total: ₹${totalAmount}. Please deposit ₹${shortfall} at the counter.`,
        currentBalance: student.walletBalance,
        totalAmount,
        shortfall
      });
    }

    // Deduct stock
    for (const oi of orderItems) {
      const menuItem = db.menu.find(m => m.id === oi.itemId);
      if (menuItem) menuItem.stock -= oi.quantity;
    }

    // Deduct balance
    student.walletBalance = Number((student.walletBalance - totalAmount).toFixed(2));

    // Unique Order ID
    const orderId = `ORD-${Date.now().toString().slice(-4)}${Math.floor(Math.random() * 900 + 100)}`;

    // Generate QR payload
    const qrPayload = JSON.stringify({
      orderId,
      studentId: student.id,
      studentName: student.fullName,
      totalAmount,
      itemCount: orderItems.reduce((acc, curr) => acc + curr.quantity, 0),
      timestamp: new Date().toISOString()
    });

    const qrCodeDataUrl = await QRCode.toDataURL(qrPayload, {
      errorCorrectionLevel: 'H',
      margin: 2,
      width: 300,
      color: {
        dark: '#0f172a',
        light: '#ffffff'
      }
    });

    const newOrder = {
      id: orderId,
      studentId: student.id,
      studentName: student.fullName,
      studentPhone: student.phone,
      items: orderItems,
      totalAmount: totalAmount,
      status: 'PLACED',
      createdAt: new Date().toISOString(),
      servedAt: null,
      qrPayload: qrPayload,
      qrCodeDataUrl: qrCodeDataUrl
    };

    db.orders.unshift(newOrder);

    // Create DEBIT transaction
    const txn = {
      id: `TXN-${Date.now()}-${Math.floor(Math.random() * 900 + 100)}`,
      userId: student.id,
      userName: student.fullName,
      type: 'DEBIT',
      amount: totalAmount,
      balanceAfter: student.walletBalance,
      description: `Food Pre-booking #${orderId} (${orderItems.length} items)`,
      referenceId: orderId,
      timestamp: new Date().toISOString()
    };
    db.transactions.unshift(txn);

    addAudit('ORDER_CREATED', `Order ${orderId} pre-booked by ${student.fullName} for ₹${totalAmount}. Remaining balance: ₹${student.walletBalance}`, student.id);
    saveDB();

    return res.status(201).json({
      success: true,
      message: '🎉 Order pre-booked successfully! Show the QR code at the dispensing counter.',
      order: newOrder,
      newBalance: student.walletBalance,
      transaction: txn
    });
  } catch (err) {
    return res.status(500).json({ success: false, message: 'Server error creating order', error: err.message });
  }
});

// 4. GET /api/transactions
app.get('/api/transactions', (req, res) => {
  try {
    const { userId } = req.query;
    if (userId) {
      const cleanUserId = userId.toString().trim();
      const list = db.transactions.filter(t => t.userId === cleanUserId);
      return res.json({ success: true, transactions: list });
    }
    return res.json({ success: true, transactions: db.transactions });
  } catch (err) {
    return res.status(500).json({ success: false, message: 'Error fetching transactions', error: err.message });
  }
});

// 5. POST /api/canteen/verify-qr (QR verification and food handover)
app.post('/api/canteen/verify-qr', (req, res) => {
  try {
    const { payload, orderId: directOrderId, adminEmail } = req.body;
    let targetOrderId = directOrderId;

    if (!targetOrderId && payload) {
      try {
        const parsed = typeof payload === 'string' ? JSON.parse(payload) : payload;
        targetOrderId = parsed.orderId || parsed.id;
      } catch {
        targetOrderId = payload.toString().trim();
      }
    }

    if (!targetOrderId) {
      return res.status(400).json({ success: false, message: 'No valid Order ID or QR payload provided.' });
    }

    const order = db.orders.find(o => o.id.toUpperCase() === targetOrderId.trim().toUpperCase());
    if (!order) {
      return res.status(404).json({
        success: false,
        message: `Order "${targetOrderId}" not found. Please verify the code.`
      });
    }

    if (order.status === 'SERVED') {
      return res.status(409).json({
        success: false,
        alreadyServed: true,
        message: `⚠️ Duplicate Pickup Prevented! Order ${order.id} was ALREADY SERVED on ${new Date(order.servedAt).toLocaleTimeString()} (${new Date(order.servedAt).toLocaleDateString()}).`,
        order
      });
    }

    order.status = 'SERVED';
    order.servedAt = new Date().toISOString();

    addAudit('ORDER_SERVED', `Order ${order.id} verified via QR code and marked SERVED. Handed to ${order.studentName}.`, adminEmail || 'admin@admin.com');
    saveDB();

    return res.json({
      success: true,
      message: `✅ Order ${order.id} verified! Hand over food to ${order.studentName}.`,
      order
    });
  } catch (err) {
    return res.status(500).json({ success: false, message: 'Error verifying order', error: err.message });
  }
});

// Additional helper endpoints
app.get('/api/admin/orders', (req, res) => {
  const { status } = req.query;
  let list = db.orders;
  if (status && status !== 'ALL') {
    list = list.filter(o => o.status.toUpperCase() === status.toUpperCase());
  }
  return res.json({ success: true, orders: list });
});

app.post('/api/admin/orders/:id/status', (req, res) => {
  const { id } = req.params;
  const { status } = req.body;
  const order = db.orders.find(o => o.id === id);
  if (!order) return res.status(404).json({ success: false, message: 'Order not found' });

  order.status = status;
  if (status === 'SERVED' && !order.servedAt) {
    order.servedAt = new Date().toISOString();
  }
  addAudit('ORDER_STATUS_CHANGED', `Order ${order.id} status changed to ${status}`, 'admin@admin.com');
  saveDB();
  return res.json({ success: true, order });
});

app.get('/api/student/orders', (req, res) => {
  const { userId } = req.query;
  if (!userId) return res.status(400).json({ success: false, message: 'User ID required' });
  const clean = userId.toString().trim();
  const orders = db.orders.filter(o => o.studentId === clean || o.studentPhone === clean);
  return res.json({ success: true, orders });
});

app.post('/api/admin/menu/update-stock', (req, res) => {
  const { itemId, stockDelta, newStock } = req.body;
  const item = db.menu.find(m => m.id === itemId);
  if (!item) return res.status(404).json({ success: false, message: 'Item not found' });

  if (newStock !== undefined) item.stock = Math.max(0, parseInt(newStock, 10));
  else if (stockDelta !== undefined) item.stock = Math.max(0, item.stock + parseInt(stockDelta, 10));

  addAudit('STOCK_UPDATED', `Stock for "${item.name}" set to ${item.stock}`, 'admin@admin.com');
  saveDB();
  return res.json({ success: true, item, menu: db.menu });
});

// POST /api/admin/menu/add - Add new dish, snack, drink, etc.
app.post('/api/admin/menu/add', (req, res) => {
  try {
    const { name, category, price, stock, description, icon, badge } = req.body;
    if (!name || price === undefined || stock === undefined) {
      return res.status(400).json({ success: false, message: 'Item name, price, and initial stock are required.' });
    }

    const numPrice = Number(price);
    const numStock = Number(stock);
    if (isNaN(numPrice) || numPrice < 0) {
      return res.status(400).json({ success: false, message: 'Please enter a valid price (₹).' });
    }
    if (isNaN(numStock) || numStock < 0) {
      return res.status(400).json({ success: false, message: 'Please enter a valid stock quantity.' });
    }

    const newItem = {
      id: `ITEM-${Date.now().toString().slice(-4)}${Math.floor(Math.random() * 900 + 100)}`,
      name: name.trim(),
      category: category ? category.trim() : 'Snacks',
      price: numPrice,
      stock: Math.floor(numStock),
      description: description ? description.trim() : '',
      icon: icon ? icon.trim() : '🍲',
      badge: badge ? badge.trim() : ''
    };

    db.menu.push(newItem);
    addAudit('MENU_ITEM_ADDED', `New item added to MITSgrub menu: "${newItem.name}" (${newItem.category}) at ₹${newItem.price} (Stock: ${newItem.stock})`, 'admin@admin.com');
    saveDB();

    return res.status(201).json({
      success: true,
      message: `🎉 "${newItem.name}" added to MITSgrub menu!`,
      item: newItem,
      menu: db.menu
    });
  } catch (err) {
    return res.status(500).json({ success: false, message: 'Server error adding menu item', error: err.message });
  }
});

// POST /api/admin/menu/delete - Remove item from menu
app.post('/api/admin/menu/delete', (req, res) => {
  try {
    const { itemId } = req.body;
    const index = db.menu.findIndex(m => m.id === itemId);
    if (index === -1) {
      return res.status(404).json({ success: false, message: 'Menu item not found.' });
    }

    const deleted = db.menu.splice(index, 1)[0];
    addAudit('MENU_ITEM_DELETED', `Item removed from MITSgrub menu: "${deleted.name}" (ID: ${deleted.id})`, 'admin@admin.com');
    saveDB();

    return res.json({
      success: true,
      message: `🗑️ "${deleted.name}" has been removed from the menu.`,
      deletedItem: deleted,
      menu: db.menu
    });
  } catch (err) {
    return res.status(500).json({ success: false, message: 'Server error deleting menu item', error: err.message });
  }
});

// DELETE /api/admin/menu/:id
app.delete('/api/admin/menu/:id', (req, res) => {
  const itemId = req.params.id;
  const index = db.menu.findIndex(m => m.id === itemId);
  if (index === -1) {
    return res.status(404).json({ success: false, message: 'Menu item not found.' });
  }
  const deleted = db.menu.splice(index, 1)[0];
  addAudit('MENU_ITEM_DELETED', `Item removed from MITSgrub menu: "${deleted.name}" (ID: ${deleted.id})`, 'admin@admin.com');
  saveDB();
  return res.json({ success: true, message: `"${deleted.name}" removed from menu.`, menu: db.menu });
});

app.get('/api/admin/audit', (req, res) => {
  return res.json({ success: true, auditLogs: db.auditLogs });
});

app.get('/api/admin/students', (req, res) => {
  const safeStudents = db.students.map(({ password: _, ...s }) => s);
  return res.json({ success: true, students: safeStudents });
});

app.get('/api/admin/stats', (req, res) => {
  const totalOrders = db.orders.length;
  const activeOrders = db.orders.filter(o => o.status !== 'SERVED' && o.status !== 'CANCELLED').length;
  const servedOrders = db.orders.filter(o => o.status === 'SERVED').length;
  const totalRevenue = db.orders.reduce((sum, o) => sum + (o.totalAmount || 0), 0);
  const totalStudents = db.students.length;
  const totalCredited = db.transactions
    .filter(t => t.type === 'CREDIT')
    .reduce((sum, t) => sum + (t.amount || 0), 0);

  return res.json({
    success: true,
    stats: {
      totalOrders,
      activeOrders,
      servedOrders,
      totalRevenue,
      totalStudents,
      totalCredited
    }
  });
});

app.post('/api/admin/reset', (req, res) => {
  db = getInitialSeedData();
  saveDB();
  return res.json({ success: true, message: 'Database reset to initial pre-seeded test data!' });
});

// GET /api/system/network-info - Returns local LAN IP and mobile QR code for easy phone access
app.get('/api/system/network-info', async (req, res) => {
  const localIp = getLocalIpAddress();
  const gatewayUrl = `http://${localIp}:${PORT}`;
  const studentUrl = `http://${localIp}:${PORT}/student`;
  const adminUrl = `http://${localIp}:${PORT}/admin`;

  try {
    const qrStudent = await QRCode.toDataURL(studentUrl, {
      margin: 2,
      width: 240,
      color: { dark: '#0f172a', light: '#ffffff' }
    });

    return res.json({
      success: true,
      ip: localIp,
      port: PORT,
      gatewayUrl,
      studentUrl,
      adminUrl,
      qrStudent
    });
  } catch (err) {
    return res.json({
      success: true,
      ip: localIp,
      port: PORT,
      gatewayUrl,
      studentUrl,
      adminUrl
    });
  }
});

// =============================================================
// HOSTEL MESS MEALS ATTENDANCE SYSTEM (BREAKFAST, LUNCH, DINNER)
// Default is YES (eating). Hostelers can opt-out (NO) per day.
// Accessible across the entire current month for hostelers & admin.
// =============================================================

// GET /api/student/meal-attendance (Fetch month's attendance for a hosteler)
app.get('/api/student/meal-attendance', (req, res) => {
  try {
    const { userId, month } = req.query;
    if (!userId) {
      return res.status(400).json({ success: false, message: 'User ID is required.' });
    }

    const cleanId = userId.toString().trim().replace(/\D/g, '') || userId.toString().trim();
    const student = db.students.find(s => s.id === cleanId || s.phone === cleanId);
    if (!student) {
      return res.status(404).json({ success: false, message: 'Student account not found.' });
    }

    if (student.studentType !== 'hosteler') {
      return res.status(403).json({
        success: false,
        isHosteler: false,
        message: 'Hostel mess meals attendance is only applicable for hostelers.'
      });
    }

    const now = new Date();
    const currentMonthStr = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}`;
    const targetMonth = (month && /^\d{4}-\d{2}$/.test(month)) ? month : currentMonthStr;

    const [yearStr, monthStr] = targetMonth.split('-');
    const year = parseInt(yearStr, 10);
    const monthNum = parseInt(monthStr, 10);
    const daysInMonth = new Date(year, monthNum, 0).getDate();

    const todayStr = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}-${String(now.getDate()).padStart(2, '0')}`;

    db.hostelMeals = db.hostelMeals || [];
    const days = [];

    for (let d = 1; d <= daysInMonth; d++) {
      const dayPad = String(d).padStart(2, '0');
      const dateStr = `${targetMonth}-${dayPad}`;
      const dateObj = new Date(year, monthNum - 1, d);
      const dayName = dateObj.toLocaleDateString('en-US', { weekday: 'short' });

      // Look up recorded preference
      const existing = db.hostelMeals.find(m => m.studentId === student.id && m.date === dateStr);

      // Default is YES (true) for all meals!
      const breakfast = existing ? existing.breakfast !== false : true;
      const lunch = existing ? existing.lunch !== false : true;
      const dinner = existing ? existing.dinner !== false : true;

      days.push({
        date: dateStr,
        dayNumber: d,
        dayName,
        isToday: dateStr === todayStr,
        isPast: dateStr < todayStr,
        breakfast,
        lunch,
        dinner,
        hasCustomized: !!existing
      });
    }

    return res.json({
      success: true,
      student: {
        id: student.id,
        fullName: student.fullName,
        studentType: student.studentType
      },
      targetMonth,
      daysInMonth,
      today: todayStr,
      days
    });
  } catch (err) {
    return res.status(500).json({ success: false, message: 'Error fetching meal attendance', error: err.message });
  }
});

// POST /api/student/meal-attendance/toggle (Update meal status for a day)
app.post('/api/student/meal-attendance/toggle', (req, res) => {
  try {
    const { userId, date, meal, status, breakfast, lunch, dinner } = req.body;
    if (!userId || !date) {
      return res.status(400).json({ success: false, message: 'User ID and Date are required.' });
    }

    const cleanId = userId.toString().trim().replace(/\D/g, '') || userId.toString().trim();
    const student = db.students.find(s => s.id === cleanId || s.phone === cleanId);
    if (!student) {
      return res.status(404).json({ success: false, message: 'Student account not found.' });
    }

    if (student.studentType !== 'hosteler') {
      return res.status(403).json({ success: false, message: 'Only hostelers can manage mess meals.' });
    }

    db.hostelMeals = db.hostelMeals || [];
    let record = db.hostelMeals.find(m => m.studentId === student.id && m.date === date);

    if (!record) {
      record = {
        id: `HM-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
        studentId: student.id,
        studentName: student.fullName,
        studentPhone: student.phone,
        date,
        breakfast: true,
        lunch: true,
        dinner: true,
        updatedAt: new Date().toISOString()
      };
      db.hostelMeals.push(record);
    }

    if (meal && ['breakfast', 'lunch', 'dinner'].includes(meal)) {
      record[meal] = (typeof status === 'boolean') ? status : !record[meal];
    }
    if (typeof breakfast === 'boolean') record.breakfast = breakfast;
    if (typeof lunch === 'boolean') record.lunch = lunch;
    if (typeof dinner === 'boolean') record.dinner = dinner;

    record.updatedAt = new Date().toISOString();
    saveDB();

    return res.json({
      success: true,
      message: `Updated meal attendance for ${date}`,
      record
    });
  } catch (err) {
    return res.status(500).json({ success: false, message: 'Error updating meal preference', error: err.message });
  }
});

// GET /api/admin/hostel-meals/summary (Daily headcount and roster for kitchen staff)
app.get('/api/admin/hostel-meals/summary', (req, res) => {
  try {
    const now = new Date();
    const todayStr = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}-${String(now.getDate()).padStart(2, '0')}`;
    const targetDate = req.query.date || todayStr;

    const hostelers = (db.students || []).filter(s => s.studentType === 'hosteler');
    db.hostelMeals = db.hostelMeals || [];

    let bEating = 0, bSkipped = 0;
    let lEating = 0, lSkipped = 0;
    let dEating = 0, dSkipped = 0;

    const roster = hostelers.map(h => {
      const record = db.hostelMeals.find(m => m.studentId === h.id && m.date === targetDate);
      const breakfast = record ? record.breakfast !== false : true;
      const lunch = record ? record.lunch !== false : true;
      const dinner = record ? record.dinner !== false : true;

      if (breakfast) bEating++; else bSkipped++;
      if (lunch) lEating++; else lSkipped++;
      if (dinner) dEating++; else dSkipped++;

      return {
        studentId: h.id,
        studentName: h.fullName,
        studentPhone: h.phone,
        email: h.email,
        date: targetDate,
        breakfast,
        lunch,
        dinner,
        skippingAny: !breakfast || !lunch || !dinner,
        skippingAll: !breakfast && !lunch && !dinner,
        updatedAt: record ? record.updatedAt : null
      };
    });

    return res.json({
      success: true,
      targetDate,
      totalHostelers: hostelers.length,
      headcount: {
        breakfast: { eating: bEating, skipped: bSkipped },
        lunch: { eating: lEating, skipped: lSkipped },
        dinner: { eating: dEating, skipped: dSkipped }
      },
      roster
    });
  } catch (err) {
    return res.status(500).json({ success: false, message: 'Error fetching hostel summary', error: err.message });
  }
});

// GET /api/admin/hostel-meals/month (Month-wide daily matrix for admin & kitchen)
app.get('/api/admin/hostel-meals/month', (req, res) => {
  try {
    const now = new Date();
    const currentMonthStr = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}`;
    const targetMonth = (req.query.month && /^\d{4}-\d{2}$/.test(req.query.month)) ? req.query.month : currentMonthStr;

    const [yearStr, monthStr] = targetMonth.split('-');
    const year = parseInt(yearStr, 10);
    const monthNum = parseInt(monthStr, 10);
    const daysInMonth = new Date(year, monthNum, 0).getDate();

    const hostelers = (db.students || []).filter(s => s.studentType === 'hosteler');
    db.hostelMeals = db.hostelMeals || [];

    const dailyStats = [];
    for (let d = 1; d <= daysInMonth; d++) {
      const dateStr = `${targetMonth}-${String(d).padStart(2, '0')}`;
      let bEating = 0, lEating = 0, dEating = 0;
      hostelers.forEach(h => {
        const record = db.hostelMeals.find(m => m.studentId === h.id && m.date === dateStr);
        if (!record || record.breakfast !== false) bEating++;
        if (!record || record.lunch !== false) lEating++;
        if (!record || record.dinner !== false) dEating++;
      });
      dailyStats.push({
        date: dateStr,
        day: d,
        breakfast: bEating,
        lunch: lEating,
        dinner: dEating,
        totalHostelers: hostelers.length
      });
    }

    return res.json({
      success: true,
      targetMonth,
      daysInMonth,
      totalHostelers: hostelers.length,
      dailyStats
    });
  } catch (err) {
    return res.status(500).json({ success: false, message: 'Error fetching monthly stats', error: err.message });
  }
});

// Start Server bound to all network interfaces (0.0.0.0)
const HOST = '0.0.0.0';
app.listen(PORT, HOST, () => {
  const localIp = getLocalIpAddress();
  console.log(`=======================================================`);
  console.log(`🍔 MITSgrub Server Available to All Devices on Your Network!`);
  console.log(`💻 This Computer:           http://localhost:${PORT}`);
  console.log(`📱 Any Phone / PC on Wi-Fi: http://${localIp}:${PORT}`);
  console.log(`🎓 MITSgrub Student App:    http://${localIp}:${PORT}/student`);
  console.log(`💼 MITSgrub Admin & POS:    http://${localIp}:${PORT}/admin`);
  console.log(`=======================================================`);
});
