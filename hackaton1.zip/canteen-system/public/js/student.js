// =========================================================
// STUDENT PORTAL JAVASCRIPT (DARK THEME & PHONE NUMBER USER ID)
// =========================================================

let currentUser = null;
let menuItems = [];
let cart = {}; // { itemId: quantity }
let currentCategory = 'All';
let menuPollingTimer = null;
let selectedStudentType = 'dayscholar';
let currentHostelAttendance = null;

function selectStudentType(type) {
  selectedStudentType = type;
  const dayOpt = document.getElementById('type-opt-dayscholar');
  const hostOpt = document.getElementById('type-opt-hosteler');
  if (type === 'hosteler') {
    if (hostOpt) hostOpt.classList.add('active');
    if (dayOpt) dayOpt.classList.remove('active');
  } else {
    if (dayOpt) dayOpt.classList.add('active');
    if (hostOpt) hostOpt.classList.remove('active');
  }
}

document.addEventListener('DOMContentLoaded', () => {
  checkAuth();
  // Start real-time menu polling every 3 seconds so admin changes reflect immediately
  menuPollingTimer = setInterval(loadMenuSilent, 3000);
});

// Toast Notification Helper
function showToast(message, type = 'info') {
  const container = document.getElementById('toast-container');
  const toast = document.createElement('div');
  toast.className = `toast toast-${type}`;
  
  const icon = type === 'success' ? '✅' : type === 'error' ? '❌' : type === 'warning' ? '⚠️' : 'ℹ️';
  toast.innerHTML = `<span>${icon}</span><span style="font-size: 0.92rem; font-weight: 600;">${message}</span>`;
  
  container.appendChild(toast);
  setTimeout(() => {
    toast.style.opacity = '0';
    toast.style.transform = 'translateX(100%)';
    toast.style.transition = 'all 0.3s ease';
    setTimeout(() => toast.remove(), 300);
  }, 4000);
}

// ---------------------------------------------------------
// AUTHENTICATION
// ---------------------------------------------------------
function checkAuth() {
  const savedUser = localStorage.getItem('canteen_student_user');
  if (savedUser) {
    try {
      currentUser = JSON.parse(savedUser);
      renderLoggedInUI();
      refreshUserData();
      loadMenu();
      loadTransactions();
      loadMyOrders();
    } catch {
      renderLoggedOutUI();
    }
  } else {
    renderLoggedOutUI();
  }
}

function renderLoggedInUI() {
  document.getElementById('auth-view').style.display = 'none';
  document.getElementById('dashboard-view').style.display = 'block';

  document.getElementById('greeting-name').innerText = `Welcome, ${currentUser.fullName}!`;
  document.getElementById('user-id-display').innerText = currentUser.id; // Phone Number
  updateWalletDisplay(currentUser.walletBalance || 0);

  // Student residency status indicator
  const isHosteler = currentUser.studentType === 'hosteler';
  const pill = document.getElementById('student-type-pill');
  if (pill) {
    pill.innerText = isHosteler ? '🏠 Hosteler' : '🎒 Day Scholar';
    pill.style.background = isHosteler ? 'rgba(16, 185, 129, 0.25)' : 'rgba(59, 130, 246, 0.25)';
    pill.style.color = isHosteler ? '#34d399' : '#93c5fd';
  }

  // Show / Hide Mess Attendance Tab (ONLY for Hostelers!)
  const messTab = document.getElementById('tab-hostel-meals');
  if (messTab) {
    messTab.style.display = isHosteler ? 'flex' : 'none';
  }

  // Top Nav User Section (NO admin link)
  const navUser = document.getElementById('nav-user-section');
  navUser.innerHTML = `
    <div class="wallet-pill" onclick="openDepositInfoModal()">
      <span>👛</span>
      <span id="nav-wallet-text">₹${Number(currentUser.walletBalance || 0).toFixed(2)}</span>
    </div>
    <div style="font-size: 0.85rem; font-weight: 700; color: var(--text-main);">${currentUser.fullName}</div>
    <button class="btn btn-secondary btn-sm" onclick="handleLogout()">Sign Out</button>
  `;
}

function renderLoggedOutUI() {
  document.getElementById('auth-view').style.display = 'block';
  document.getElementById('dashboard-view').style.display = 'none';
  document.getElementById('cart-float-btn').style.display = 'none';

  const navUser = document.getElementById('nav-user-section');
  navUser.innerHTML = `
    <button class="btn btn-primary btn-sm" onclick="switchAuthTab('login')">Sign In</button>
  `;
}

function switchAuthTab(tab) {
  const loginBtn = document.getElementById('tab-login-btn');
  const regBtn = document.getElementById('tab-register-btn');
  const loginForm = document.getElementById('login-form');
  const regForm = document.getElementById('register-form');

  if (tab === 'login') {
    loginBtn.classList.add('active');
    regBtn.classList.remove('active');
    loginForm.style.display = 'block';
    regForm.style.display = 'none';
  } else {
    regBtn.classList.add('active');
    loginBtn.classList.remove('active');
    regForm.style.display = 'block';
    loginForm.style.display = 'none';
  }
}

async function handleLogin(e) {
  e.preventDefault();
  const email = document.getElementById('login-email').value.trim();
  const password = document.getElementById('login-password').value.trim();

  try {
    const res = await fetch('/api/auth/login', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email, password, role: 'student' })
    });
    const data = await res.json();

    if (data.success) {
      currentUser = data.user;
      localStorage.setItem('canteen_student_user', JSON.stringify(currentUser));
      showToast(`Signed in! User ID: ${currentUser.id}`, 'success');
      renderLoggedInUI();
      loadMenu();
      loadTransactions();
      loadMyOrders();
    } else {
      showToast(data.message, 'error');
    }
  } catch (err) {
    showToast('Failed to connect: ' + err.message, 'error');
  }
}

async function handleRegister(e) {
  e.preventDefault();
  const fullName = document.getElementById('reg-name').value.trim();
  const email = document.getElementById('reg-email').value.trim();
  const phone = document.getElementById('reg-phone').value.trim();
  const password = document.getElementById('reg-password').value.trim();

  try {
    const res = await fetch('/api/auth/register', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        fullName,
        email,
        phone,
        password,
        studentType: selectedStudentType
      })
    });
    const data = await res.json();

    if (data.success) {
      currentUser = data.user;
      localStorage.setItem('canteen_student_user', JSON.stringify(currentUser));
      showToast(data.message, 'success');
      renderLoggedInUI();
      loadMenu();
      loadTransactions();
      loadMyOrders();
    } else {
      showToast(data.message, 'error');
    }
  } catch (err) {
    showToast('Registration failed: ' + err.message, 'error');
  }
}

function handleLogout() {
  currentUser = null;
  localStorage.removeItem('canteen_student_user');
  cart = {};
  renderLoggedOutUI();
  showToast('Logged out of Student Portal.', 'info');
}

async function refreshUserData() {
  if (!currentUser) return;
  try {
    const res = await fetch(`/api/auth/me?userId=${currentUser.id}`);
    const data = await res.json();
    if (data.success) {
      currentUser = data.user;
      localStorage.setItem('canteen_student_user', JSON.stringify(currentUser));
      updateWalletDisplay(currentUser.walletBalance);
      renderLoggedInUI();
    }
  } catch (err) {
    console.warn('Error refreshing user data:', err);
  }
}

function updateWalletDisplay(balance) {
  const formatted = `₹${Number(balance || 0).toFixed(2)}`;
  const display = document.getElementById('wallet-balance-display');
  if (display) display.innerText = formatted;
  const navText = document.getElementById('nav-wallet-text');
  if (navText) navText.innerText = formatted;
}

function copyUserId() {
  if (!currentUser) return;
  navigator.clipboard.writeText(currentUser.id).then(() => {
    showToast(`Copied User ID: ${currentUser.id}`, 'info');
  }).catch(() => {
    showToast(`User ID: ${currentUser.id}`, 'info');
  });
}

function openDepositInfoModal() {
  if (!currentUser) return;
  document.getElementById('deposit-modal-userid').innerText = currentUser.id;
  document.getElementById('deposit-modal-name').innerText = currentUser.fullName;
  document.getElementById('deposit-modal').classList.add('active');
}

function closeDepositInfoModal() {
  document.getElementById('deposit-modal').classList.remove('active');
}

// ---------------------------------------------------------
// TABS
// ---------------------------------------------------------
function switchTab(tabName) {
  const tabs = ['menu', 'orders', 'transactions', 'hostel-meals'];
  tabs.forEach(t => {
    const tabElem = document.getElementById(`tab-${t}`);
    const viewElem = document.getElementById(`view-${t}`);
    if (tabElem && viewElem) {
      if (t === tabName) {
        tabElem.classList.add('active');
        viewElem.style.display = 'block';
      } else {
        tabElem.classList.remove('active');
        viewElem.style.display = 'none';
      }
    }
  });

  if (tabName === 'orders') loadMyOrders();
  if (tabName === 'transactions') loadTransactions();
  if (tabName === 'menu') loadMenu();
  if (tabName === 'hostel-meals') loadHostelMealAttendance();
}

// ---------------------------------------------------------
// MENU & CART
// ---------------------------------------------------------
async function loadMenu() {
  try {
    const res = await fetch('/api/menu');
    const data = await res.json();
    if (data.success) {
      menuItems = data.menu;
      cleanCartFromDeletedItems();
      renderMenu();
      updateCategoryChips();
    }
  } catch (err) {
    showToast('Failed to load menu: ' + err.message, 'error');
  }
}

// Silent polling for real-time menu additions, stock updates, and deletions
async function loadMenuSilent() {
  try {
    const res = await fetch('/api/menu');
    const data = await res.json();
    if (data.success && Array.isArray(data.menu)) {
      const oldStr = JSON.stringify(menuItems);
      const newStr = JSON.stringify(data.menu);
      if (oldStr !== newStr) {
        menuItems = data.menu;
        cleanCartFromDeletedItems();
        updateCategoryChips();
        if (document.getElementById('tab-menu') && document.getElementById('tab-menu').classList.contains('active')) {
          renderMenu();
        }
        if (document.getElementById('cart-modal') && document.getElementById('cart-modal').classList.contains('active')) {
          renderCartModal();
        }
      }
    }
  } catch {
    // Silent fail on transient poll
  }
}

function cleanCartFromDeletedItems() {
  let cartModified = false;
  for (const itemId of Object.keys(cart)) {
    const exists = menuItems.find(m => m.id === itemId);
    if (!exists) {
      delete cart[itemId];
      cartModified = true;
    }
  }
  if (cartModified) {
    updateCartSummary();
  }
}

function updateCategoryChips() {
  const chipsContainer = document.getElementById('category-chips');
  if (!chipsContainer) return;
  const categories = ['All', ...new Set(menuItems.map(m => m.category || 'General'))];
  
  // Only rebuild if categories set changed
  const currentChips = Array.from(chipsContainer.querySelectorAll('.chip')).map(c => c.innerText.trim());
  const match = categories.length === currentChips.length && categories.every(c => currentChips.includes(c));
  if (match) return;

  chipsContainer.innerHTML = categories.map(cat => `
    <div class="chip ${cat === currentCategory ? 'selected' : ''}" onclick="filterCategory('${cat}')">${cat}</div>
  `).join('');
}

function filterCategory(category) {
  currentCategory = category;
  const chips = document.querySelectorAll('#category-chips .chip');
  chips.forEach(c => {
    if (c.innerText.trim() === category) {
      c.classList.add('selected');
    } else {
      c.classList.remove('selected');
    }
  });
  renderMenu();
}

function renderMenu() {
  const container = document.getElementById('menu-grid');
  if (!container) return;

  const filtered = currentCategory === 'All' 
    ? menuItems 
    : menuItems.filter(m => m.category.toLowerCase() === currentCategory.toLowerCase());

  if (filtered.length === 0) {
    container.innerHTML = `<div style="grid-column: 1/-1; text-align: center; padding: 3rem; color: var(--text-dim);">No items found in this category.</div>`;
    return;
  }

  container.innerHTML = filtered.map(item => {
    const inCartQty = cart[item.id] || 0;
    const isOutOfStock = item.stock <= 0;

    return `
      <div class="menu-card">
        <div class="menu-card-top">
          <span class="menu-card-icon">${item.icon || '🍲'}</span>
          ${item.badge ? `<span class="menu-card-badge">${item.badge}</span>` : ''}
        </div>
        <div class="menu-card-body">
          <span class="menu-card-category">${item.category}</span>
          <h4 class="menu-card-title">${item.name}</h4>
          <p class="menu-card-desc">${item.description || ''}</p>
          
          <div class="menu-card-footer">
            <div>
              <div class="menu-card-price">₹${item.price}</div>
              <div class="menu-card-stock" style="color: ${item.stock <= 5 ? 'var(--danger)' : 'var(--text-muted)'}; font-weight: ${item.stock <= 5 ? '700' : '500'};">
                ${isOutOfStock ? '❌ Sold Out' : `⚡ ${item.stock} portions left`}
              </div>
            </div>

            <div>
              ${isOutOfStock ? `
                <button class="btn btn-secondary btn-sm" disabled>Sold Out</button>
              ` : inCartQty > 0 ? `
                <div class="qty-control">
                  <button class="qty-btn" onclick="updateItemQty('${item.id}', -1)">-</button>
                  <span class="qty-num">${inCartQty}</span>
                  <button class="qty-btn" onclick="updateItemQty('${item.id}', 1)">+</button>
                </div>
              ` : `
                <button class="btn btn-outline btn-sm" onclick="updateItemQty('${item.id}', 1)">
                  ➕ Add
                </button>
              `}
            </div>
          </div>
        </div>
      </div>
    `;
  }).join('');

  updateCartSummary();
}

function updateItemQty(itemId, delta) {
  const item = menuItems.find(m => m.id === itemId);
  if (!item) return;

  const currentQty = cart[itemId] || 0;
  const newQty = currentQty + delta;

  if (newQty > item.stock) {
    showToast(`Sorry, only ${item.stock} left for ${item.name}!`, 'warning');
    return;
  }

  if (newQty <= 0) {
    delete cart[itemId];
  } else {
    cart[itemId] = newQty;
  }

  renderMenu();
  renderCartModal();
}

function updateCartSummary() {
  const floatBtn = document.getElementById('cart-float-btn');
  const countBadge = document.getElementById('cart-count');
  const totalBadge = document.getElementById('cart-total-badge');

  let totalCount = 0;
  let totalPrice = 0;

  for (const [itemId, qty] of Object.entries(cart)) {
    const item = menuItems.find(m => m.id === itemId);
    if (item) {
      totalCount += qty;
      totalPrice += item.price * qty;
    }
  }

  if (totalCount > 0) {
    floatBtn.style.display = 'inline-flex';
    countBadge.innerText = totalCount;
    totalBadge.innerText = `₹${totalPrice.toFixed(2)}`;
  } else {
    floatBtn.style.display = 'none';
  }
}

// ---------------------------------------------------------
// CART MODAL & CHECKOUT
// ---------------------------------------------------------
function openCartModal() {
  renderCartModal();
  document.getElementById('cart-modal').classList.add('active');
}

function closeCartModal() {
  document.getElementById('cart-modal').classList.remove('active');
}

function renderCartModal() {
  const listContainer = document.getElementById('cart-items-list');
  const subtotalElem = document.getElementById('cart-subtotal');
  const grandTotalElem = document.getElementById('cart-grand-total');
  const walletCheck = document.getElementById('cart-wallet-check');
  const checkoutBtn = document.getElementById('checkout-btn');

  const cartEntries = Object.entries(cart);

  if (cartEntries.length === 0) {
    listContainer.innerHTML = `<div style="text-align: center; padding: 2.5rem 1rem; color: var(--text-dim);">Your cart is empty. Pick some delicious items!</div>`;
    subtotalElem.innerText = '₹0.00';
    grandTotalElem.innerText = '₹0.00';
    walletCheck.innerHTML = '';
    checkoutBtn.disabled = true;
    return;
  }

  let total = 0;
  listContainer.innerHTML = cartEntries.map(([itemId, qty]) => {
    const item = menuItems.find(m => m.id === itemId);
    if (!item) return '';
    const itemTotal = item.price * qty;
    total += itemTotal;

    return `
      <div style="display: flex; align-items: center; justify-content: space-between; padding: 0.75rem 0; border-bottom: 1px solid var(--border-color);">
        <div style="display: flex; align-items: center; gap: 0.75rem;">
          <span style="font-size: 1.6rem;">${item.icon || '🍲'}</span>
          <div>
            <div style="font-weight: 700; color: var(--text-main);">${item.name}</div>
            <div style="font-size: 0.82rem; color: var(--text-muted);">₹${item.price} each</div>
          </div>
        </div>

        <div style="display: flex; align-items: center; gap: 1rem;">
          <div class="qty-control">
            <button class="qty-btn" onclick="updateItemQty('${item.id}', -1)">-</button>
            <span class="qty-num">${qty}</span>
            <button class="qty-btn" onclick="updateItemQty('${item.id}', 1)">+</button>
          </div>
          <div style="font-weight: 800; min-width: 60px; text-align: right; color: var(--text-main);">₹${itemTotal}</div>
        </div>
      </div>
    `;
  }).join('');

  subtotalElem.innerText = `₹${total.toFixed(2)}`;
  grandTotalElem.innerText = `₹${total.toFixed(2)}`;

  const currentBalance = currentUser ? currentUser.walletBalance : 0;

  if (currentBalance >= total) {
    walletCheck.innerHTML = `
      <div style="background: rgba(16, 185, 129, 0.12); border: 1px solid rgba(16, 185, 129, 0.3); border-radius: var(--radius-md); padding: 0.75rem; font-size: 0.88rem; color: #34d399;">
        ✅ <strong>Wallet Ready:</strong> Current Balance: <strong>₹${currentBalance.toFixed(2)}</strong>. Balance after deduction: <strong>₹${(currentBalance - total).toFixed(2)}</strong>.
      </div>
    `;
    checkoutBtn.disabled = false;
    checkoutBtn.innerText = `Confirm & Pay ₹${total.toFixed(2)}`;
  } else {
    const shortfall = (total - currentBalance).toFixed(2);
    walletCheck.innerHTML = `
      <div style="background: rgba(239, 68, 68, 0.12); border: 1px solid rgba(239, 68, 68, 0.3); border-radius: var(--radius-md); padding: 0.75rem; font-size: 0.88rem; color: #f87171;">
        ⚠️ <strong>Insufficient Balance:</strong> Short by <strong>₹${shortfall}</strong>. (Balance: ₹${currentBalance.toFixed(2)}).
        <div style="margin-top: 0.5rem;">
          <button class="btn btn-success btn-sm" onclick="closeCartModal(); openDepositInfoModal();">
            💵 How to Deposit Cash at Counter
          </button>
        </div>
      </div>
    `;
    checkoutBtn.disabled = true;
    checkoutBtn.innerText = `Insufficient Funds (Short by ₹${shortfall})`;
  }
}

async function handleCheckout() {
  if (!currentUser) {
    showToast('Please sign in first.', 'error');
    return;
  }

  const items = Object.entries(cart).map(([itemId, quantity]) => ({ itemId, quantity }));
  if (items.length === 0) return;

  const checkoutBtn = document.getElementById('checkout-btn');
  checkoutBtn.disabled = true;
  checkoutBtn.innerText = 'Deducting Wallet & Booking...';

  try {
    const res = await fetch('/api/orders/create', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        userId: currentUser.id,
        items: items
      })
    });

    const data = await res.json();

    if (data.success) {
      cart = {};
      closeCartModal();

      currentUser.walletBalance = data.newBalance;
      localStorage.setItem('canteen_student_user', JSON.stringify(currentUser));
      updateWalletDisplay(currentUser.walletBalance);

      openQrModal(data.order);
      showToast('🎉 Food pre-booked successfully!', 'success');

      loadMenu();
      loadTransactions();
      loadMyOrders();
    } else {
      showToast(data.message, 'error');
    }
  } catch (err) {
    showToast('Checkout failed: ' + err.message, 'error');
  } finally {
    checkoutBtn.disabled = false;
    checkoutBtn.innerText = 'Confirm & Pay from Wallet';
  }
}

// ---------------------------------------------------------
// QR MODAL
// ---------------------------------------------------------
function openQrModal(order) {
  document.getElementById('qr-modal-order-id').innerText = `Order #${order.id}`;
  document.getElementById('qr-code-img').src = order.qrCodeDataUrl;
  document.getElementById('qr-modal-student-name').innerText = `${order.studentName} (ID: ${order.studentId})`;
  document.getElementById('qr-modal-total').innerText = `₹${Number(order.totalAmount).toFixed(2)}`;

  const itemsList = order.items.map(i => `${i.quantity}× ${i.name} (₹${i.subtotal})`).join(', ');
  document.getElementById('qr-modal-items').innerText = itemsList;

  document.getElementById('qr-modal').classList.add('active');
}

function closeQrModal() {
  document.getElementById('qr-modal').classList.remove('active');
}

// ---------------------------------------------------------
// MY ORDERS
// ---------------------------------------------------------
async function loadMyOrders() {
  if (!currentUser) return;

  try {
    const res = await fetch(`/api/student/orders?userId=${currentUser.id}`);
    const data = await res.json();

    if (data.success) {
      renderMyOrders(data.orders);
    }
  } catch (err) {
    console.error('Error fetching orders:', err);
  }
}

function renderMyOrders(orders) {
  const container = document.getElementById('orders-container');
  const badge = document.getElementById('orders-badge');

  const activeCount = orders.filter(o => o.status !== 'SERVED' && o.status !== 'CANCELLED').length;
  if (activeCount > 0) {
    badge.style.display = 'inline-block';
    badge.innerText = activeCount;
  } else {
    badge.style.display = 'none';
  }

  if (orders.length === 0) {
    container.innerHTML = `
      <div class="card" style="text-align: center; padding: 3rem; color: var(--text-dim);">
        <div style="font-size: 3rem; margin-bottom: 0.5rem;">📦</div>
        <p style="font-size: 1.1rem; font-weight: 700;">No orders placed yet!</p>
        <p style="font-size: 0.88rem; margin-top: 0.25rem;">Browse the food menu and pre-book your meals.</p>
        <button class="btn btn-primary btn-sm" style="margin-top: 1rem;" onclick="switchTab('menu')">Browse Menu</button>
      </div>
    `;
    return;
  }

  container.innerHTML = orders.map(order => {
    let statusBadgeClass = 'badge-placed';
    if (order.status === 'PREPARING') statusBadgeClass = 'badge-preparing';
    if (order.status === 'READY') statusBadgeClass = 'badge-ready';
    if (order.status === 'SERVED') statusBadgeClass = 'badge-served';

    const itemsSummary = order.items.map(i => `
      <div style="display: flex; justify-content: space-between; font-size: 0.9rem; padding: 0.25rem 0;">
        <span>${i.icon || '🍲'} ${i.name} × ${i.quantity}</span>
        <span style="font-weight: 700; color: var(--text-main);">₹${i.subtotal}</span>
      </div>
    `).join('');

    return `
      <div class="card" style="margin-bottom: 1.25rem;">
        <div style="display: flex; flex-wrap: wrap; align-items: center; justify-content: space-between; gap: 0.75rem; padding-bottom: 0.75rem; border-bottom: 1px solid var(--border-color);">
          <div>
            <span style="font-weight: 800; font-size: 1.1rem; color: var(--text-main);">${order.id}</span>
            <span style="font-size: 0.8rem; color: var(--text-dim); margin-left: 0.5rem;">
              ${new Date(order.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })} • ${new Date(order.createdAt).toLocaleDateString()}
            </span>
          </div>
          <div style="display: flex; align-items: center; gap: 0.75rem;">
            <span class="badge ${statusBadgeClass}">${order.status}</span>
            <button class="btn btn-outline btn-sm" onclick='openQrModal(${JSON.stringify(order).replace(/'/g, "&apos;")})'>
              📱 View Pickup QR
            </button>
          </div>
        </div>

        <div style="margin: 0.85rem 0; background: rgba(0,0,0,0.2); padding: 0.75rem; border-radius: var(--radius-md);">
          ${itemsSummary}
        </div>

        <div style="display: flex; justify-content: space-between; align-items: center; padding-top: 0.75rem; border-top: 1px dashed var(--border-color);">
          <span style="font-size: 0.85rem; color: var(--text-muted);">Total Paid via Wallet</span>
          <span style="font-size: 1.25rem; font-weight: 900; color: #34d399;">₹${Number(order.totalAmount).toFixed(2)}</span>
        </div>
      </div>
    `;
  }).join('');
}

// ---------------------------------------------------------
// TRANSACTIONS
// ---------------------------------------------------------
async function loadTransactions() {
  if (!currentUser) return;

  try {
    const res = await fetch(`/api/transactions?userId=${currentUser.id}`);
    const data = await res.json();

    if (data.success) {
      renderTransactions(data.transactions);
    }
  } catch (err) {
    console.error('Error fetching transactions:', err);
  }
}

function renderTransactions(transactions) {
  const tbody = document.getElementById('transactions-table-body');
  if (!tbody) return;

  if (transactions.length === 0) {
    tbody.innerHTML = `<tr><td colspan="7" style="text-align: center; color: var(--text-dim); padding: 2rem;">No wallet transactions recorded yet.</td></tr>`;
    return;
  }

  tbody.innerHTML = transactions.map(t => {
    const isCredit = t.type === 'CREDIT';
    const typeBadge = isCredit ? `<span class="badge badge-credit">+ CREDIT</span>` : `<span class="badge badge-debit">- DEBIT</span>`;
    const amountFormatted = `${isCredit ? '+' : '-'}₹${Number(t.amount).toFixed(2)}`;
    const amountColor = isCredit ? '#34d399' : '#f87171';

    return `
      <tr>
        <td style="font-size: 0.85rem; color: var(--text-muted);">
          ${new Date(t.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}<br>
          <span style="font-size: 0.75rem; color: var(--text-dim);">${new Date(t.timestamp).toLocaleDateString()}</span>
        </td>
        <td style="font-family: monospace; font-size: 0.82rem; color: var(--text-muted);">${t.id}</td>
        <td style="font-weight: 600;">${t.description}</td>
        <td><span class="badge" style="background: rgba(255,255,255,0.05); color: var(--text-muted);">${t.referenceId || 'N/A'}</span></td>
        <td>${typeBadge}</td>
        <td style="font-weight: 800; color: ${amountColor};">${amountFormatted}</td>
        <td style="font-weight: 700; color: var(--text-main);">₹${Number(t.balanceAfter).toFixed(2)}</td>
      </tr>
    `;
  }).join('');
}

// ---------------------------------------------------------
// HOSTEL MESS MEAL ATTENDANCE (HOSTELERS ONLY)
// ---------------------------------------------------------
async function loadHostelMealAttendance(month) {
  if (!currentUser || currentUser.studentType !== 'hosteler') return;

  const daysContainer = document.getElementById('hostel-days-container');
  const monthLabel = document.getElementById('hostel-month-label');
  const todayCard = document.getElementById('hostel-today-card');

  if (daysContainer) {
    daysContainer.innerHTML = '<div style="grid-column: 1/-1; text-align: center; padding: 2rem; color: var(--text-muted);">🔄 Loading meal schedule...</div>';
  }

  try {
    const url = `/api/student/meal-attendance?userId=${currentUser.id}${month ? '&month=' + month : ''}`;
    const res = await fetch(url);
    const data = await res.json();

    if (!data.success) {
      if (daysContainer) daysContainer.innerHTML = `<div style="grid-column: 1/-1; color: #f87171; text-align: center; padding: 2rem;">${data.message}</div>`;
      return;
    }

    currentHostelAttendance = data;

    // Display formatted Month header
    if (monthLabel) {
      const [y, m] = data.targetMonth.split('-');
      const d = new Date(parseInt(y, 10), parseInt(m, 10) - 1, 1);
      monthLabel.innerText = d.toLocaleDateString('en-US', { month: 'long', year: 'numeric' });
    }

    // Render Today's card
    const todayData = data.days.find(d => d.isToday);
    if (todayCard && todayData) {
      todayCard.innerHTML = `
        <div style="display: flex; flex-wrap: wrap; justify-content: space-between; align-items: center; gap: 1rem; margin-bottom: 0.75rem;">
          <div>
            <div style="font-size: 0.78rem; text-transform: uppercase; font-weight: 800; color: #34d399; letter-spacing: 0.05em;">TODAY'S MESS STATUS</div>
            <h3 style="font-size: 1.3rem; font-weight: 800; color: var(--text-main); margin-top: 0.15rem;">${todayData.dayName}, ${todayData.date}</h3>
          </div>
          <div style="display: flex; gap: 0.5rem;">
            <button class="btn btn-secondary btn-sm" onclick="setAllMealsForDay('${todayData.date}', true)">
              ✅ Eat All Today
            </button>
            <button class="btn btn-secondary btn-sm" onclick="setAllMealsForDay('${todayData.date}', false)">
              ❌ Skip All Today
            </button>
          </div>
        </div>

        <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(140px, 1fr)); gap: 0.75rem;">
          <div style="background: rgba(0,0,0,0.3); padding: 0.75rem; border-radius: var(--radius-sm); display: flex; justify-content: space-between; align-items: center;">
            <span style="font-weight: 700;">🍳 Breakfast:</span>
            <button class="meal-toggle-btn ${todayData.breakfast ? 'btn-eating' : 'btn-skipped'}" onclick="toggleHostelMeal('${todayData.date}', 'breakfast', ${todayData.breakfast})">
              ${todayData.breakfast ? '✅ YES' : '❌ NO'}
            </button>
          </div>
          <div style="background: rgba(0,0,0,0.3); padding: 0.75rem; border-radius: var(--radius-sm); display: flex; justify-content: space-between; align-items: center;">
            <span style="font-weight: 700;">🍱 Lunch:</span>
            <button class="meal-toggle-btn ${todayData.lunch ? 'btn-eating' : 'btn-skipped'}" onclick="toggleHostelMeal('${todayData.date}', 'lunch', ${todayData.lunch})">
              ${todayData.lunch ? '✅ YES' : '❌ NO'}
            </button>
          </div>
          <div style="background: rgba(0,0,0,0.3); padding: 0.75rem; border-radius: var(--radius-sm); display: flex; justify-content: space-between; align-items: center;">
            <span style="font-weight: 700;">🍲 Dinner:</span>
            <button class="meal-toggle-btn ${todayData.dinner ? 'btn-eating' : 'btn-skipped'}" onclick="toggleHostelMeal('${todayData.date}', 'dinner', ${todayData.dinner})">
              ${todayData.dinner ? '✅ YES' : '❌ NO'}
            </button>
          </div>
        </div>
      `;
    }

    // Render calendar of all days in month
    if (daysContainer) {
      daysContainer.innerHTML = data.days.map(d => {
        const isToday = d.isToday;

        return `
          <div class="meal-day-card ${isToday ? 'today-card' : ''}" id="meal-card-${d.date}">
            <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 0.65rem;">
              <div>
                <span style="font-size: 0.8rem; color: var(--text-dim); text-transform: uppercase; font-weight: 700;">${d.dayName}</span>
                <div style="font-size: 1.15rem; font-weight: 800; color: var(--text-main);">${d.date}</div>
              </div>
              ${isToday ? '<span class="badge badge-active" style="font-size: 0.75rem;">TODAY</span>' : ''}
            </div>

            <!-- Breakfast Row -->
            <div class="meal-toggle-row">
              <span style="font-size: 0.88rem; font-weight: 700; color: var(--text-main);">🍳 Breakfast</span>
              <button class="meal-toggle-btn ${d.breakfast ? 'btn-eating' : 'btn-skipped'}" onclick="toggleHostelMeal('${d.date}', 'breakfast', ${d.breakfast})">
                ${d.breakfast ? '✅ YES' : '❌ NO'}
              </button>
            </div>

            <!-- Lunch Row -->
            <div class="meal-toggle-row">
              <span style="font-size: 0.88rem; font-weight: 700; color: var(--text-main);">🍱 Lunch</span>
              <button class="meal-toggle-btn ${d.lunch ? 'btn-eating' : 'btn-skipped'}" onclick="toggleHostelMeal('${d.date}', 'lunch', ${d.lunch})">
                ${d.lunch ? '✅ YES' : '❌ NO'}
              </button>
            </div>

            <!-- Dinner Row -->
            <div class="meal-toggle-row">
              <span style="font-size: 0.88rem; font-weight: 700; color: var(--text-main);">🍲 Dinner</span>
              <button class="meal-toggle-btn ${d.dinner ? 'btn-eating' : 'btn-skipped'}" onclick="toggleHostelMeal('${d.date}', 'dinner', ${d.dinner})">
                ${d.dinner ? '✅ YES' : '❌ NO'}
              </button>
            </div>

            <!-- Quick Day Actions -->
            <div style="display: flex; justify-content: space-between; margin-top: 0.6rem; padding-top: 0.5rem; border-top: 1px dashed var(--border-color); font-size: 0.75rem;">
              <button class="btn btn-outline btn-sm" style="padding: 0.15rem 0.5rem; font-size: 0.72rem;" onclick="setAllMealsForDay('${d.date}', true)">
                Eat All
              </button>
              <button class="btn btn-outline btn-sm" style="padding: 0.15rem 0.5rem; font-size: 0.72rem;" onclick="setAllMealsForDay('${d.date}', false)">
                Skip All
              </button>
            </div>
          </div>
        `;
      }).join('');
    }
  } catch (err) {
    if (daysContainer) daysContainer.innerHTML = `<div style="grid-column: 1/-1; color: #f87171; text-align: center; padding: 2rem;">Error loading attendance: ${err.message}</div>`;
  }
}

async function toggleHostelMeal(date, meal, currentStatus) {
  if (!currentUser) return;
  const newStatus = !currentStatus;

  // Optimistic UI update in currentHostelAttendance
  if (currentHostelAttendance && currentHostelAttendance.days) {
    const day = currentHostelAttendance.days.find(d => d.date === date);
    if (day) day[meal] = newStatus;
  }

  const mealName = meal.charAt(0).toUpperCase() + meal.slice(1);
  showToast(`${mealName} for ${date} set to ${newStatus ? 'YES (Eating)' : 'NO (Skipped)'}`, newStatus ? 'success' : 'info');

  try {
    const res = await fetch('/api/student/meal-attendance/toggle', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        userId: currentUser.id,
        date,
        meal,
        status: newStatus
      })
    });
    const data = await res.json();
    if (!data.success) {
      showToast(data.message, 'error');
    }
    loadHostelMealAttendance(currentHostelAttendance ? currentHostelAttendance.targetMonth : null);
  } catch (err) {
    showToast('Failed to save: ' + err.message, 'error');
    loadHostelMealAttendance(currentHostelAttendance ? currentHostelAttendance.targetMonth : null);
  }
}

async function setAllMealsForDay(date, status) {
  if (!currentUser) return;
  try {
    const res = await fetch('/api/student/meal-attendance/toggle', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        userId: currentUser.id,
        date,
        breakfast: status,
        lunch: status,
        dinner: status
      })
    });
    const data = await res.json();
    if (data.success) {
      showToast(`All meals for ${date} set to ${status ? 'YES (Eating)' : 'NO (Skipped)'}`, status ? 'success' : 'warning');
      loadHostelMealAttendance(currentHostelAttendance ? currentHostelAttendance.targetMonth : null);
    } else {
      showToast(data.message, 'error');
    }
  } catch (err) {
    showToast('Failed to save: ' + err.message, 'error');
  }
}
