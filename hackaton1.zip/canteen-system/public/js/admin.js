// =========================================================
// CANTEEN OPERATIONS & CASHIER POS JAVASCRIPT
// Single Admin (admin@admin.com) | Direct Wallet Cashier Credit
// =========================================================

let currentAdmin = null;
let html5QrCode = null;
let isScannerRunning = false;
let availableCameras = [];
let autoRefreshTimer = null;
let lookupDebounce = null;

document.addEventListener('DOMContentLoaded', () => {
  checkAdminAuth();
});

// Toast Helper
function showToast(message, type = 'info') {
  const container = document.getElementById('toast-container');
  const toast = document.createElement('div');
  toast.className = `toast toast-${type}`;
  
  const icon = type === 'success' ? '✅' : type === 'error' ? '❌' : type === 'warning' ? '⚠️' : 'ℹ️';
  toast.innerHTML = `<span>${icon}</span><span style="font-size: 0.92rem; font-weight: 600;">${message}</span>`;
  
  container.appendChild(toast);
  setTimeout(() => {
    toast.style.opacity = '0';
    toast.style.transform = 'translateX(100%)';
    toast.style.transition = 'all 0.3s ease';
    setTimeout(() => toast.remove(), 300);
  }, 4000);
}

// ---------------------------------------------------------
// AUTHENTICATION & MANDATORY PASSWORD CHANGE
// ---------------------------------------------------------
function checkAdminAuth() {
  const saved = localStorage.getItem('canteen_admin_user');
  if (saved) {
    try {
      currentAdmin = JSON.parse(saved);
      renderAdminLoggedIn();
    } catch {
      renderAdminLoggedOut();
    }
  } else {
    renderAdminLoggedOut();
  }
}

function renderAdminLoggedIn() {
  document.getElementById('admin-auth-view').style.display = 'none';
  document.getElementById('admin-dashboard-view').style.display = 'block';

  const navUser = document.getElementById('admin-nav-user');
  navUser.innerHTML = `
    <span class="badge badge-active">Admin Active</span>
    <span style="font-size: 0.88rem; font-weight: 700; color: var(--text-main);">${currentAdmin.email}</span>
    <button class="btn btn-secondary btn-sm" onclick="handleAdminLogout()">Sign Out</button>
  `;

  // Start data loading and polling
  refreshStats();
  loadAdminOrders();
  loadRecentCredits();

  if (autoRefreshTimer) clearInterval(autoRefreshTimer);
  autoRefreshTimer = setInterval(() => {
    refreshStats();
    if (document.getElementById('tab-orders-queue').classList.contains('active')) {
      loadAdminOrders(true);
    }
  }, 4000);
}

function renderAdminLoggedOut() {
  document.getElementById('admin-auth-view').style.display = 'block';
  document.getElementById('admin-dashboard-view').style.display = 'none';
  if (autoRefreshTimer) clearInterval(autoRefreshTimer);

  const navUser = document.getElementById('admin-nav-user');
  navUser.innerHTML = `
    <span style="font-size: 0.85rem; color: var(--text-muted); display: flex; align-items: center; gap: 0.4rem;">
      <span class="status-dot warning" style="display: inline-block;"></span> Not Logged In
    </span>
  `;
}

async function handleAdminLogin(e) {
  e.preventDefault();
  const email = document.getElementById('admin-login-email').value.trim();
  const password = document.getElementById('admin-login-password').value.trim();

  try {
    const res = await fetch('/api/auth/login', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email, password, role: 'admin' })
    });
    const data = await res.json();

    if (data.success) {
      currentAdmin = data.user;
      localStorage.setItem('canteen_admin_user', JSON.stringify(currentAdmin));

      // CHECK MANDATORY PASSWORD CHANGE
      if (data.mustChangePassword) {
        document.getElementById('change-curr-pass').value = password;
        document.getElementById('password-change-modal').classList.add('active');
        showToast('First login detected: Please set your new password.', 'warning');
        return;
      }

      showToast(`Signed in as ${currentAdmin.email}`, 'success');
      renderAdminLoggedIn();
    } else {
      showToast(data.message, 'error');
    }
  } catch (err) {
    showToast('Login error: ' + err.message, 'error');
  }
}

async function handleMandatoryPasswordChange(e) {
  e.preventDefault();
  const currentPassword = document.getElementById('change-curr-pass').value.trim();
  const newPassword = document.getElementById('change-new-pass').value.trim();
  const confirmPassword = document.getElementById('change-confirm-pass').value.trim();

  if (newPassword !== confirmPassword) {
    showToast('New passwords do not match!', 'error');
    return;
  }

  if (newPassword === 'admin') {
    showToast('Please pick a password different from the default "admin".', 'warning');
    return;
  }

  try {
    const res = await fetch('/api/admin/change-password', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ currentPassword, newPassword })
    });
    const data = await res.json();

    if (data.success) {
      document.getElementById('password-change-modal').classList.remove('active');
      currentAdmin = data.user;
      localStorage.setItem('canteen_admin_user', JSON.stringify(currentAdmin));
      showToast('Master password changed successfully!', 'success');
      renderAdminLoggedIn();
    } else {
      showToast(data.message, 'error');
    }
  } catch (err) {
    showToast('Error changing password: ' + err.message, 'error');
  }
}

function handleAdminLogout() {
  stopCameraScanner();
  currentAdmin = null;
  localStorage.removeItem('canteen_admin_user');
  renderAdminLoggedOut();
  showToast('Signed out of POS terminal.', 'info');
}

// ---------------------------------------------------------
// TABS
// ---------------------------------------------------------
function switchAdminTab(tabName) {
  // If leaving QR scanner, stop the camera to free resources
  if (tabName !== 'qr-scanner' && isScannerRunning) {
    stopCameraScanner();
  }

  const tabs = ['cashier-credit', 'orders-queue', 'qr-scanner', 'stock', 'hostel-mess', 'audit-logs'];
  tabs.forEach(t => {
    const tabBtn = document.getElementById(`tab-${t}`);
    const tabView = document.getElementById(`admin-view-${t}`);
    if (tabBtn && tabView) {
      if (t === tabName) {
        tabBtn.classList.add('active');
        tabView.style.display = 'block';
      } else {
        tabBtn.classList.remove('active');
        tabView.style.display = 'none';
      }
    }
  });

  if (tabName === 'cashier-credit') loadRecentCredits();
  if (tabName === 'orders-queue') loadAdminOrders();
  if (tabName === 'qr-scanner') initQrScannerTab();
  if (tabName === 'stock') loadStockManagement();
  if (tabName === 'hostel-mess') initAdminHostelTab();
  if (tabName === 'audit-logs') loadAuditLogs();
}

// ---------------------------------------------------------
// DASHBOARD STATS
// ---------------------------------------------------------
async function refreshStats() {
  try {
    const res = await fetch('/api/admin/stats');
    const data = await res.json();
    if (data.success) {
      const s = data.stats;
      document.getElementById('kpi-revenue').innerText = `₹${Number(s.totalRevenue || 0).toFixed(2)}`;
      document.getElementById('kpi-active-orders').innerText = s.activeOrders || 0;
      document.getElementById('kpi-served-orders').innerText = s.servedOrders || 0;
      document.getElementById('kpi-total-credited').innerText = `₹${Number(s.totalCredited || 0).toFixed(2)}`;
    }
  } catch (err) {
    console.warn('Error fetching stats:', err);
  }
}

// ---------------------------------------------------------
// DIRECT CASHIER CREDIT SYSTEM
// ---------------------------------------------------------
function quickFillPreseededStudent() {
  const input = document.getElementById('credit-user-id');
  input.value = '9876543210';
  handleStudentLookup();
}

function handleStudentLookup() {
  clearTimeout(lookupDebounce);
  const input = document.getElementById('credit-user-id');
  const previewBox = document.getElementById('student-preview-box');
  const val = input.value.trim().replace(/\D/g, '');

  if (val.length < 10) {
    previewBox.style.display = 'none';
    return;
  }

  lookupDebounce = setTimeout(async () => {
    try {
      const res = await fetch(`/api/admin/lookup-student?userId=${val}`);
      const data = await res.json();

      if (data.success) {
        const s = data.student;
        previewBox.style.display = 'block';
        previewBox.innerHTML = `
          <div style="display: flex; justify-content: space-between; align-items: center;">
            <div>
              <div style="font-weight: 800; color: #34d399; font-size: 1rem;">✅ Verified Student: ${s.fullName}</div>
              <div style="font-size: 0.8rem; color: var(--text-muted);">Email: ${s.email} | User ID: ${s.id}</div>
            </div>
            <div style="text-align: right;">
              <div style="font-size: 0.75rem; color: var(--text-muted); text-transform: uppercase;">Current Balance</div>
              <div style="font-size: 1.2rem; font-weight: 900; color: #38bdf8;">₹${Number(s.walletBalance).toFixed(2)}</div>
            </div>
          </div>
        `;
      } else {
        previewBox.style.display = 'block';
        previewBox.innerHTML = `
          <div style="color: #f87171; font-size: 0.88rem; font-weight: 700;">
            ⚠️ Student not found with User ID / Phone: ${val}
          </div>
        `;
      }
    } catch {
      previewBox.style.display = 'none';
    }
  }, 250);
}

function selectCreditAmount(amount) {
  document.getElementById('credit-amount-input').value = amount;
  const chips = document.querySelectorAll('#admin-view-cashier-credit .chip');
  chips.forEach(c => {
    if (c.innerText.includes(`₹${amount}`)) {
      c.classList.add('selected');
    } else {
      c.classList.remove('selected');
    }
  });
}

async function handleDirectCredit(e) {
  e.preventDefault();
  const userId = document.getElementById('credit-user-id').value.trim();
  const amount = Number(document.getElementById('credit-amount-input').value);
  const note = document.getElementById('credit-note-input').value.trim();

  if (!userId) {
    showToast('Please enter the Student User ID (Phone Number).', 'warning');
    return;
  }

  if (!amount || amount <= 0) {
    showToast('Please enter a valid credit amount.', 'warning');
    return;
  }

  const submitBtn = document.getElementById('credit-submit-btn');
  submitBtn.disabled = true;
  submitBtn.innerText = 'Crediting Wallet...';

  try {
    const res = await fetch('/api/admin/credit-wallet', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        userId,
        amount,
        note,
        adminEmail: currentAdmin ? currentAdmin.email : 'admin@admin.com'
      })
    });

    const data = await res.json();

    if (data.success) {
      showToast(data.message, 'success');

      // Show receipt banner
      const banner = document.getElementById('credit-success-banner');
      banner.style.display = 'block';
      document.getElementById('receipt-student-name').innerText = data.student.fullName;
      document.getElementById('receipt-user-id').innerText = `User ID (Phone): ${data.student.id}`;
      document.getElementById('receipt-amount').innerText = `+₹${data.creditedAmount.toFixed(2)}`;
      document.getElementById('receipt-new-balance').innerText = `₹${data.newBalance.toFixed(2)}`;
      document.getElementById('receipt-timestamp').innerText = `Time: ${new Date(data.transaction.timestamp).toLocaleTimeString()} (${new Date(data.transaction.timestamp).toLocaleDateString()})`;

      // Refresh lookup preview
      handleStudentLookup();

      // Clear note
      document.getElementById('credit-note-input').value = '';

      refreshStats();
      loadRecentCredits();
    } else {
      showToast(data.message, 'error');
    }
  } catch (err) {
    showToast('Error crediting wallet: ' + err.message, 'error');
  } finally {
    submitBtn.disabled = false;
    submitBtn.innerText = '⚡ Credit Wallet Directly';
  }
}

async function loadRecentCredits() {
  try {
    const res = await fetch('/api/transactions');
    const data = await res.json();
    if (data.success) {
      const credits = data.transactions.filter(t => t.type === 'CREDIT');
      renderRecentCredits(credits);
    }
  } catch (err) {
    console.warn('Error fetching credits:', err);
  }
}

function renderRecentCredits(credits) {
  const tbody = document.getElementById('recent-credits-tbody');
  if (!tbody) return;

  if (credits.length === 0) {
    tbody.innerHTML = `<tr><td colspan="7" style="text-align: center; color: var(--text-dim); padding: 2rem;">No cash credits recorded yet.</td></tr>`;
    return;
  }

  tbody.innerHTML = credits.map(c => {
    return `
      <tr>
        <td style="font-size: 0.82rem; color: var(--text-muted);">${new Date(c.timestamp).toLocaleString()}</td>
        <td style="font-family: monospace; font-size: 0.8rem; color: var(--text-dim);">${c.id}</td>
        <td style="font-weight: 700; color: var(--text-main);">${c.userName}</td>
        <td style="font-family: monospace; font-weight: 800; color: #38bdf8;">${c.userId}</td>
        <td style="font-weight: 800; color: #34d399;">+₹${Number(c.amount).toFixed(2)}</td>
        <td style="font-weight: 700; color: var(--text-main);">₹${Number(c.balanceAfter).toFixed(2)}</td>
        <td style="font-size: 0.88rem; color: var(--text-muted);">${c.description}</td>
      </tr>
    `;
  }).join('');
}

// ---------------------------------------------------------
// KITCHEN QUEUE
// ---------------------------------------------------------
async function loadAdminOrders(isSilent = false) {
  const filter = document.getElementById('filter-order-status').value;
  try {
    const res = await fetch(`/api/admin/orders?status=${filter}`);
    const data = await res.json();
    if (data.success) {
      renderAdminOrders(data.orders);
    }
  } catch (err) {
    if (!isSilent) showToast('Failed to load orders: ' + err.message, 'error');
  }
}

function renderAdminOrders(orders) {
  const container = document.getElementById('admin-orders-container');
  if (!container) return;

  if (orders.length === 0) {
    container.innerHTML = `
      <div class="card" style="text-align: center; padding: 3.5rem 1rem; color: var(--text-dim);">
        <div style="font-size: 3rem; margin-bottom: 0.5rem;">🍳</div>
        <p style="font-size: 1.1rem; font-weight: 700; color: var(--text-muted);">Queue is clear</p>
        <p style="font-size: 0.85rem; margin-top: 0.25rem;">New pre-bookings will automatically appear here.</p>
      </div>
    `;
    return;
  }

  container.innerHTML = orders.map(order => {
    let badgeClass = 'badge-placed';
    if (order.status === 'PREPARING') badgeClass = 'badge-preparing';
    if (order.status === 'READY') badgeClass = 'badge-ready';
    if (order.status === 'SERVED') badgeClass = 'badge-served';

    const itemsList = order.items.map(i => `
      <div style="display: flex; justify-content: space-between; font-size: 0.92rem; padding: 0.35rem 0; border-bottom: 1px dashed var(--border-color);">
        <span><strong style="color: var(--text-main);">${i.quantity}×</strong> ${i.name}</span>
        <span style="color: var(--text-muted); font-weight: 700;">₹${i.subtotal}</span>
      </div>
    `).join('');

    let actionButtons = '';
    if (order.status === 'PLACED') {
      actionButtons = `
        <button class="btn btn-outline btn-sm" onclick="updateOrderStatus('${order.id}', 'PREPARING')">
          👨‍🍳 Start Preparing
        </button>
        <button class="btn btn-primary btn-sm" onclick="updateOrderStatus('${order.id}', 'READY')">
          ⚡ Mark Ready
        </button>
      `;
    } else if (order.status === 'PREPARING') {
      actionButtons = `
        <button class="btn btn-primary btn-sm" onclick="updateOrderStatus('${order.id}', 'READY')">
          ⚡ Mark Ready
        </button>
      `;
    } else if (order.status === 'READY') {
      actionButtons = `
        <button class="btn btn-success btn-sm" onclick="verifyAndServeDirectly('${order.id}')">
          ✅ Hand Over & Mark Served
        </button>
      `;
    } else if (order.status === 'SERVED') {
      actionButtons = `
        <span style="font-size: 0.82rem; color: #34d399; font-weight: 700;">
          Served at ${new Date(order.servedAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
        </span>
      `;
    }

    return `
      <div class="card" style="margin-bottom: 1.25rem;">
        <div style="display: flex; flex-wrap: wrap; align-items: center; justify-content: space-between; gap: 0.75rem; padding-bottom: 0.75rem; border-bottom: 1px solid var(--border-color);">
          <div>
            <span style="font-size: 1.2rem; font-weight: 900; color: var(--text-main);">${order.id}</span>
            <span class="badge ${badgeClass}" style="margin-left: 0.5rem;">${order.status}</span>
            <span style="font-size: 0.8rem; color: var(--text-dim); margin-left: 0.5rem;">• ${new Date(order.createdAt).toLocaleTimeString()}</span>
          </div>

          <div style="font-size: 0.92rem; color: var(--text-muted);">
            👤 <strong>${order.studentName}</strong> (Phone/User ID: <span style="color: #38bdf8; font-family: monospace;">${order.studentPhone}</span>)
          </div>
        </div>

        <div style="margin: 0.85rem 0; background: rgba(0,0,0,0.25); padding: 0.85rem; border-radius: var(--radius-md);">
          ${itemsList}
        </div>

        <div style="display: flex; flex-wrap: wrap; justify-content: space-between; align-items: center; gap: 0.75rem;">
          <div>
            <span style="font-size: 0.82rem; color: var(--text-dim);">Paid via Digital Wallet:</span>
            <span style="font-size: 1.25rem; font-weight: 900; color: #34d399; margin-left: 0.35rem;">₹${Number(order.totalAmount).toFixed(2)}</span>
          </div>

          <div style="display: flex; gap: 0.5rem; align-items: center;">
            ${actionButtons}
          </div>
        </div>
      </div>
    `;
  }).join('');
}

async function updateOrderStatus(orderId, status) {
  try {
    const res = await fetch(`/api/admin/orders/${orderId}/status`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ status })
    });
    const data = await res.json();
    if (data.success) {
      showToast(`Order #${orderId} moved to ${status}`, 'success');
      loadAdminOrders();
      refreshStats();
    } else {
      showToast(data.message, 'error');
    }
  } catch (err) {
    showToast('Failed to update status: ' + err.message, 'error');
  }
}

async function verifyAndServeDirectly(orderId) {
  try {
    const res = await fetch('/api/canteen/verify-qr', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ orderId, adminEmail: currentAdmin ? currentAdmin.email : 'admin@admin.com' })
    });
    const data = await res.json();
    if (data.success) {
      showToast(data.message, 'success');
      loadAdminOrders();
      refreshStats();
    } else {
      showToast(data.message, 'warning');
    }
  } catch (err) {
    showToast('Verification failed: ' + err.message, 'error');
  }
}

// ---------------------------------------------------------
// QR SCANNER & VERIFICATION
// ---------------------------------------------------------
async function initQrScannerTab() {
  const isLocalhost = location.hostname === 'localhost' || location.hostname === '127.0.0.1';
  const notice = document.getElementById('qr-lan-notice');
  if (notice) {
    if (!window.isSecureContext && !isLocalhost) {
      notice.style.display = 'block';
    } else {
      notice.style.display = 'none';
    }
  }

  try {
    if (typeof Html5Qrcode !== 'undefined' && Html5Qrcode.getCameras) {
      const devices = await Html5Qrcode.getCameras();
      availableCameras = devices || [];
      const group = document.getElementById('camera-select-group');
      const select = document.getElementById('camera-select');
      if (availableCameras.length > 1 && select) {
        select.innerHTML = availableCameras.map((cam, idx) => {
          const label = cam.label || `Camera ${idx + 1} (${cam.id.slice(0, 6)}...)`;
          return `<option value="${cam.id}">${label}</option>`;
        }).join('');
        if (group) group.style.display = 'block';
      }
    }
  } catch (err) {
    console.warn('Camera device enumeration note:', err);
  }
}

async function startCameraScanner() {
  if (isScannerRunning) return;

  const qrStatus = document.getElementById('qr-scanner-status');
  const qrBadge = document.getElementById('qr-live-badge');

  if (qrStatus) qrStatus.innerHTML = '<span style="color: #38bdf8;">🔄 Requesting camera permission...</span>';

  // Check if browser blocks live camera on plain HTTP over LAN
  const isLocalhost = location.hostname === 'localhost' || location.hostname === '127.0.0.1';
  if (!window.isSecureContext && !isLocalhost && !navigator.mediaDevices) {
    const msg = 'Live webcam video is blocked by browser security on plain HTTP over Wi-Fi. Please tap "📁 Snap / Upload QR Photo" to take a photo of the QR code!';
    if (qrStatus) qrStatus.innerHTML = `<span style="color: #f59e0b;">⚠️ ${msg}</span>`;
    showToast(msg, 'warning');
    return;
  }

  try {
    if (html5QrCode && isScannerRunning) {
      try { await html5QrCode.stop(); } catch (_) {}
      isScannerRunning = false;
    }

    const readerElem = document.getElementById('qr-reader');
    if (readerElem) readerElem.innerHTML = '';

    if (!html5QrCode) {
      html5QrCode = new Html5Qrcode("qr-reader");
    }

    const config = {
      fps: 10,
      qrbox: (viewfinderWidth, viewfinderHeight) => {
        const edge = Math.min(viewfinderWidth, viewfinderHeight);
        const boxSize = Math.max(160, Math.floor(edge * 0.72));
        return { width: boxSize, height: boxSize };
      },
      aspectRatio: 1.0
    };

    const onScanSuccess = (decodedText) => {
      showToast('📸 QR Code detected! Verifying...', 'info');
      processOrderVerification(decodedText);
      stopCameraScanner();
    };

    const onScanError = () => {
      // per-frame silent tick
    };

    // Camera startup strategy with fallbacks
    const selectElem = document.getElementById('camera-select');
    let targetCamera = selectElem && selectElem.value ? selectElem.value : null;

    if (!targetCamera) {
      try {
        if (!availableCameras || availableCameras.length === 0) {
          availableCameras = await Html5Qrcode.getCameras();
        }
        if (availableCameras && availableCameras.length > 0) {
          const backCam = availableCameras.find(c => 
            (c.label || '').toLowerCase().includes('back') || 
            (c.label || '').toLowerCase().includes('rear') || 
            (c.label || '').toLowerCase().includes('environment')
          );
          targetCamera = backCam ? backCam.id : availableCameras[0].id;
          if (selectElem) selectElem.value = targetCamera;
        }
      } catch (enumErr) {
        console.warn('Could not enumerate cameras, trying constraint fallback:', enumErr);
      }
    }

    let started = false;

    // Attempt 1: Target camera ID if known
    if (targetCamera) {
      try {
        await html5QrCode.start(targetCamera, config, onScanSuccess, onScanError);
        started = true;
      } catch (camErr) {
        console.warn('Failed with cameraId, falling back to facingMode:', camErr);
      }
    }

    // Attempt 2: Environment camera (Mobile rear camera)
    if (!started) {
      try {
        await html5QrCode.start({ facingMode: "environment" }, config, onScanSuccess, onScanError);
        started = true;
      } catch (envErr) {
        console.warn('Failed with facingMode environment, trying user facingMode:', envErr);
      }
    }

    // Attempt 3: User camera (Laptop front webcam!)
    if (!started) {
      try {
        await html5QrCode.start({ facingMode: "user" }, config, onScanSuccess, onScanError);
        started = true;
      } catch (userErr) {
        console.warn('Failed with facingMode user, trying default video:', userErr);
      }
    }

    // Attempt 4: Any video stream
    if (!started) {
      await html5QrCode.start({}, config, onScanSuccess, onScanError);
      started = true;
    }

    if (started) {
      isScannerRunning = true;
      document.getElementById('start-scan-btn').style.display = 'none';
      document.getElementById('stop-scan-btn').style.display = 'inline-flex';
      if (qrBadge) {
        qrBadge.className = 'badge badge-active';
        qrBadge.innerText = '🟢 Scanning Active';
      }
      if (qrStatus) {
        qrStatus.innerHTML = '<span style="color: #34d399; font-weight: 700;">🟢 Camera active — Hold student Order QR in front of camera</span>';
      }
    }

  } catch (err) {
    console.error('All camera startup attempts failed:', err);
    isScannerRunning = false;
    document.getElementById('start-scan-btn').style.display = 'inline-flex';
    document.getElementById('stop-scan-btn').style.display = 'none';
    if (qrBadge) {
      qrBadge.className = 'badge badge-debit';
      qrBadge.innerText = 'Camera Error';
    }

    let errorDetail = 'Camera could not be started. ';
    if (err.name === 'NotAllowedError' || err.name === 'PermissionDeniedError') {
      errorDetail = 'Camera permission was denied. Please allow camera access in browser settings.';
    } else if (err.name === 'NotFoundError' || err.name === 'DevicesNotFoundError') {
      errorDetail = 'No webcam or camera device was found on this machine.';
    } else if (err.name === 'NotReadableError' || err.name === 'TrackStartError') {
      errorDetail = 'The webcam is currently in use by another program (Zoom, Teams, etc.).';
    } else if (!window.isSecureContext && !isLocalhost) {
      errorDetail = 'Browser blocks live camera on plain HTTP over Wi-Fi. Please use "Snap / Upload QR Photo" instead.';
    } else if (err.message) {
      errorDetail += err.message;
    }

    if (qrStatus) {
      qrStatus.innerHTML = `<span style="color: #f87171;">⚠️ ${errorDetail}</span>`;
    }
    showToast(errorDetail, 'warning');
  }
}

async function stopCameraScanner() {
  if (html5QrCode && isScannerRunning) {
    try {
      await html5QrCode.stop();
    } catch (err) {
      console.warn('Error stopping scanner:', err);
    }
  }

  isScannerRunning = false;
  document.getElementById('start-scan-btn').style.display = 'inline-flex';
  document.getElementById('stop-scan-btn').style.display = 'none';

  const qrBadge = document.getElementById('qr-live-badge');
  if (qrBadge) {
    qrBadge.className = 'badge';
    qrBadge.style.background = 'rgba(255,255,255,0.06)';
    qrBadge.style.color = 'var(--text-muted)';
    qrBadge.innerText = 'Ready';
  }

  const qrStatus = document.getElementById('qr-scanner-status');
  if (qrStatus) {
    qrStatus.innerHTML = '<span style="color: var(--text-dim);">Scanner stopped. Click Start Scanner or Snap Photo.</span>';
  }

  const readerElem = document.getElementById('qr-reader');
  if (readerElem) {
    readerElem.innerHTML = `
      <div id="qr-placeholder-text" style="color: var(--text-dim); padding: 2rem 1rem;">
        <div style="font-size: 2.5rem; margin-bottom: 0.5rem;">📷</div>
        <div style="font-size: 0.95rem; font-weight: 700; color: var(--text-muted);">Webcam Idle</div>
        <div style="font-size: 0.82rem; margin-top: 0.25rem;">Click "Start Webcam Scanner" or snap a photo of the QR code.</div>
      </div>
    `;
  }
}

async function handleCameraSelectionChange() {
  if (isScannerRunning) {
    await stopCameraScanner();
    await startCameraScanner();
  }
}

async function handleQrImageUpload(event) {
  const file = event.target.files && event.target.files[0];
  if (!file) return;

  const qrStatus = document.getElementById('qr-scanner-status');
  if (qrStatus) {
    qrStatus.innerHTML = '<span style="color: #38bdf8;">🔄 Analyzing image for QR code...</span>';
  }
  showToast('🔍 Analyzing image for QR code...', 'info');

  try {
    if (isScannerRunning) {
      await stopCameraScanner();
    }

    if (!html5QrCode) {
      html5QrCode = new Html5Qrcode("qr-reader");
    }

    const decodedText = await html5QrCode.scanFile(file, true);
    if (decodedText) {
      showToast('📸 QR Code detected! Verifying...', 'success');
      if (qrStatus) {
        qrStatus.innerHTML = '<span style="color: #34d399; font-weight: 700;">✅ QR Code successfully decoded from photo</span>';
      }
      processOrderVerification(decodedText);
    }
  } catch (err) {
    console.warn('QR photo scan error:', err);
    const msg = 'No QR code could be detected in this image. Please ensure the QR code is clearly visible and well-lit.';
    if (qrStatus) {
      qrStatus.innerHTML = `<span style="color: #f87171;">⚠️ ${msg}</span>`;
    }
    showToast(msg, 'warning');
  } finally {
    event.target.value = '';
  }
}

function handleManualVerify() {
  const input = document.getElementById('manual-order-input');
  const val = input.value.trim();
  if (!val) {
    showToast('Please enter an Order ID.', 'warning');
    return;
  }
  processOrderVerification(val);
  input.value = '';
}

async function processOrderVerification(payload) {
  try {
    const res = await fetch('/api/canteen/verify-qr', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        payload,
        adminEmail: currentAdmin ? currentAdmin.email : 'admin@admin.com'
      })
    });

    const data = await res.json();
    displayVerificationResult(data);

    if (data.success) {
      showToast(data.message, 'success');
      refreshStats();
      loadAdminOrders();
    } else if (data.alreadyServed) {
      showToast('⚠️ Duplicate Pickup Prevented! Already served.', 'warning');
    } else {
      showToast(data.message, 'error');
    }
  } catch (err) {
    showToast('Error verifying code: ' + err.message, 'error');
  }
}

function displayVerificationResult(data) {
  const placeholder = document.getElementById('verification-empty-placeholder');
  const details = document.getElementById('verification-details');

  placeholder.style.display = 'none';
  details.style.display = 'block';

  if (!data.order) {
    details.innerHTML = `
      <div style="background: rgba(239, 68, 68, 0.12); border: 1px solid rgba(239, 68, 68, 0.3); border-radius: var(--radius-md); padding: 1.5rem; text-align: center;">
        <div style="font-size: 2.5rem; margin-bottom: 0.5rem;">❌</div>
        <h4 style="font-size: 1.15rem; color: #f87171; font-weight: 800;">Invalid QR Code or Order ID</h4>
        <p style="font-size: 0.88rem; color: var(--text-muted); margin-top: 0.25rem;">${data.message}</p>
      </div>
    `;
    return;
  }

  const order = data.order;
  const isAlreadyServed = data.alreadyServed;

  const itemsHtml = order.items.map(i => `
    <div style="display: flex; justify-content: space-between; padding: 0.4rem 0; border-bottom: 1px dashed var(--border-color); font-size: 0.95rem;">
      <span><strong>${i.quantity}×</strong> ${i.name}</span>
      <span style="font-weight: 700;">₹${i.subtotal}</span>
    </div>
  `).join('');

  details.innerHTML = `
    <div style="background: ${isAlreadyServed ? 'rgba(245, 158, 11, 0.1)' : 'rgba(16, 185, 129, 0.1)'}; border: 2px solid ${isAlreadyServed ? '#f59e0b' : '#10b981'}; border-radius: var(--radius-lg); padding: 1.5rem; margin-bottom: 1rem;">
      <div style="display: flex; align-items: center; justify-content: space-between; margin-bottom: 0.75rem;">
        <span class="badge ${isAlreadyServed ? 'badge-debit' : 'badge-served'}" style="font-size: 0.85rem; padding: 0.3rem 0.8rem;">
          ${isAlreadyServed ? '⚠️ DUPLICATE PICKUP PREVENTED' : '✅ PAYMENT VERIFIED & SERVED'}
        </span>
        <span style="font-weight: 900; font-size: 1.2rem; color: var(--text-main);">${order.id}</span>
      </div>

      <p style="font-size: 0.92rem; color: ${isAlreadyServed ? '#fbbf24' : '#34d399'}; font-weight: 700; margin-bottom: 1rem;">
        ${data.message}
      </p>

      <div style="background: rgba(0,0,0,0.3); border-radius: var(--radius-md); padding: 1rem; border: 1px solid var(--border-color); margin-bottom: 1rem;">
        <div style="display: flex; justify-content: space-between; margin-bottom: 0.5rem; font-size: 0.9rem;">
          <span style="color: var(--text-muted);">Student Name:</span>
          <span style="font-weight: 800; color: var(--text-main);">${order.studentName}</span>
        </div>
        <div style="display: flex; justify-content: space-between; margin-bottom: 0.75rem; font-size: 0.9rem;">
          <span style="color: var(--text-muted);">User ID (Phone):</span>
          <span style="font-weight: 700; font-family: monospace; color: #38bdf8;">${order.studentPhone || 'N/A'}</span>
        </div>

        <div style="font-weight: 800; font-size: 0.82rem; text-transform: uppercase; color: var(--text-dim); margin: 0.75rem 0 0.25rem;">
          Items Handed Over:
        </div>
        ${itemsHtml}

        <div style="display: flex; justify-content: space-between; margin-top: 0.75rem; padding-top: 0.5rem; border-top: 1px solid var(--border-color); font-weight: 900; font-size: 1.15rem; color: var(--text-main);">
          <span>Total Order Value:</span>
          <span style="color: #34d399;">₹${Number(order.totalAmount).toFixed(2)}</span>
        </div>
      </div>

      <div style="font-size: 0.8rem; color: var(--text-dim); text-align: center;">
        Placed: ${new Date(order.createdAt).toLocaleString()} • Handed Over: ${new Date(order.servedAt || Date.now()).toLocaleTimeString()}
      </div>
    </div>
  `;
}

// ---------------------------------------------------------
// MENU & INVENTORY MANAGEMENT (DISHES, SNACKS, DRINKS)
// ---------------------------------------------------------
function toggleAddMenuForm() {
  const card = document.getElementById('add-menu-form-card');
  if (!card) return;
  if (card.style.display === 'none' || !card.style.display) {
    card.style.display = 'block';
    document.getElementById('new-item-name').focus();
  } else {
    card.style.display = 'none';
  }
}

function selectEmojiPreset(emoji) {
  const input = document.getElementById('new-item-icon');
  if (input) input.value = emoji;
}

async function handleCreateMenuItem(e) {
  e.preventDefault();
  const name = document.getElementById('new-item-name').value.trim();
  const category = document.getElementById('new-item-category').value;
  const price = document.getElementById('new-item-price').value;
  const stock = document.getElementById('new-item-stock').value;
  const icon = document.getElementById('new-item-icon').value.trim() || '🍲';
  const badge = document.getElementById('new-item-badge').value.trim();
  const description = document.getElementById('new-item-desc').value.trim();

  if (!name || !price || stock === '') {
    showToast('Name, price, and initial stock are required.', 'warning');
    return;
  }

  const submitBtn = document.getElementById('add-menu-submit-btn');
  submitBtn.disabled = true;
  submitBtn.innerText = 'Adding to Menu...';

  try {
    const res = await fetch('/api/admin/menu/add', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        name,
        category,
        price: Number(price),
        stock: Number(stock),
        icon,
        badge,
        description
      })
    });

    const data = await res.json();
    if (data.success) {
      showToast(data.message, 'success');
      // Reset form
      document.getElementById('new-item-name').value = '';
      document.getElementById('new-item-price').value = '';
      document.getElementById('new-item-stock').value = '';
      document.getElementById('new-item-badge').value = '';
      document.getElementById('new-item-desc').value = '';
      document.getElementById('new-item-icon').value = '🍲';
      document.getElementById('add-menu-form-card').style.display = 'none';
      loadStockManagement();
    } else {
      showToast(data.message, 'error');
    }
  } catch (err) {
    showToast('Error adding item: ' + err.message, 'error');
  } finally {
    submitBtn.disabled = false;
    submitBtn.innerText = '✨ Save & Publish to Student Menu';
  }
}

async function deleteMenuItem(itemId, itemName) {
  if (!confirm(`Are you sure you want to permanently delete "${itemName}" from the MITSgrub menu?`)) {
    return;
  }

  try {
    const res = await fetch('/api/admin/menu/delete', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ itemId })
    });
    const data = await res.json();
    if (data.success) {
      showToast(data.message, 'success');
      loadStockManagement();
    } else {
      showToast(data.message, 'error');
    }
  } catch (err) {
    showToast('Error deleting item: ' + err.message, 'error');
  }
}

async function loadStockManagement() {
  try {
    const res = await fetch('/api/menu');
    const data = await res.json();
    if (data.success) {
      renderStockTable(data.menu);
    }
  } catch (err) {
    showToast('Failed to load menu: ' + err.message, 'error');
  }
}

function renderStockTable(menu) {
  const tbody = document.getElementById('stock-table-body');
  if (!tbody) return;

  if (menu.length === 0) {
    tbody.innerHTML = `<tr><td colspan="7" style="text-align: center; color: var(--text-dim); padding: 2.5rem;">No menu items available. Click "➕ Add New Menu Item" above to add dishes, snacks, or drinks.</td></tr>`;
    return;
  }

  tbody.innerHTML = menu.map(item => {
    let stockStatus = `<span class="badge badge-active">In Stock</span>`;
    if (item.stock <= 0) {
      stockStatus = `<span class="badge badge-debit">Out of Stock</span>`;
    } else if (item.stock <= 5) {
      stockStatus = `<span class="badge badge-placed">Low Stock</span>`;
    }

    const safeName = item.name.replace(/'/g, "\\'");

    return `
      <tr>
        <td>
          <div style="display: flex; align-items: center; gap: 0.65rem;">
            <span style="font-size: 1.6rem;">${item.icon || '🍲'}</span>
            <div>
              <div style="font-weight: 800; color: var(--text-main); font-size: 0.95rem;">
                ${item.name}
                ${item.badge ? `<span class="badge badge-active" style="font-size: 0.68rem; margin-left: 0.35rem; padding: 0.1rem 0.4rem;">${item.badge}</span>` : ''}
              </div>
              <div style="font-size: 0.78rem; color: var(--text-muted); max-width: 260px; white-space: nowrap; overflow: hidden; text-overflow: ellipsis;">
                ${item.description || 'No description provided'}
              </div>
            </div>
          </div>
        </td>
        <td><span class="badge" style="background: rgba(255,255,255,0.06); color: var(--text-muted);">${item.category}</span></td>
        <td style="font-weight: 800; color: #34d399; font-size: 1rem;">₹${item.price}</td>
        <td style="font-size: 1.15rem; font-weight: 900; color: ${item.stock <= 5 ? 'var(--danger)' : 'var(--text-main)'};">
          ${item.stock}
        </td>
        <td>${stockStatus}</td>
        <td>
          <div style="display: flex; gap: 0.35rem;">
            <button class="btn btn-secondary btn-sm" style="padding: 0.2rem 0.5rem;" onclick="updateStock('${item.id}', 10)">+10</button>
            <button class="btn btn-secondary btn-sm" style="padding: 0.2rem 0.5rem;" onclick="updateStock('${item.id}', 25)">+25</button>
            <button class="btn btn-outline btn-sm" style="padding: 0.2rem 0.5rem;" onclick="promptCustomStock('${item.id}', ${item.stock})">Set</button>
          </div>
        </td>
        <td>
          <button class="btn btn-danger btn-sm" style="padding: 0.25rem 0.6rem; font-size: 0.8rem;" onclick="deleteMenuItem('${item.id}', '${safeName}')">
            🗑️ Delete
          </button>
        </td>
      </tr>
    `;
  }).join('');
}

async function updateStock(itemId, delta) {
  try {
    const res = await fetch('/api/admin/menu/update-stock', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ itemId, stockDelta: delta })
    });
    const data = await res.json();
    if (data.success) {
      showToast(`Updated stock for ${data.item.name} to ${data.item.stock}`, 'success');
      renderStockTable(data.menu);
    }
  } catch (err) {
    showToast('Stock update failed: ' + err.message, 'error');
  }
}

function promptCustomStock(itemId, currentStock) {
  const val = prompt('Enter new stock count for this item:', currentStock);
  if (val !== null && !isNaN(val)) {
    fetch('/api/admin/menu/update-stock', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ itemId, newStock: parseInt(val, 10) })
    })
    .then(r => r.json())
    .then(data => {
      if (data.success) {
        showToast(`Stock updated to ${data.item.stock}`, 'success');
        renderStockTable(data.menu);
      }
    });
  }
}

// ---------------------------------------------------------
// AUDIT LOGS
// ---------------------------------------------------------
async function loadAuditLogs() {
  try {
    const res = await fetch('/api/admin/audit');
    const data = await res.json();
    if (data.success) {
      renderAuditLogs(data.auditLogs);
    }
  } catch (err) {
    showToast('Failed to load audit logs: ' + err.message, 'error');
  }
}

function renderAuditLogs(logs) {
  const tbody = document.getElementById('audit-table-body');
  if (!tbody) return;

  if (logs.length === 0) {
    tbody.innerHTML = `<tr><td colspan="5" style="text-align: center; color: var(--text-dim); padding: 2rem;">No logs recorded yet.</td></tr>`;
    return;
  }

  tbody.innerHTML = logs.map(l => {
    return `
      <tr>
        <td style="font-size: 0.82rem; color: var(--text-muted);">${new Date(l.timestamp).toLocaleString()}</td>
        <td style="font-family: monospace; font-size: 0.8rem; color: var(--text-dim);">${l.id}</td>
        <td><span class="badge" style="background: rgba(255,255,255,0.06); color: var(--text-main);">${l.action}</span></td>
        <td style="font-size: 0.85rem; font-weight: 700; color: #38bdf8;">${l.actor}</td>
        <td style="font-size: 0.88rem; color: var(--text-muted);">${l.details}</td>
      </tr>
    `;
  }).join('');
}

// ---------------------------------------------------------
// RESET DATABASE
// ---------------------------------------------------------
async function handleResetDatabase() {
  if (!confirm('Are you sure you want to reset the database to pre-seeded state? (Rahul Sharma User ID 9876543210 with ₹150, Single Admin admin@admin.com with default password admin)')) {
    return;
  }

  try {
    const res = await fetch('/api/admin/reset', { method: 'POST' });
    const data = await res.json();
    if (data.success) {
      showToast('Database reset to pre-seeded test data!', 'success');
      refreshStats();
      loadAdminOrders();
      loadRecentCredits();
      loadStockManagement();
      loadAuditLogs();
    }
  } catch (err) {
    showToast('Reset failed: ' + err.message, 'error');
  }
}

// ---------------------------------------------------------
// HOSTEL MESS ATTENDANCE & KITCHEN HEADCOUNT (ADMIN)
// ---------------------------------------------------------
let adminHostelRosterData = [];

function initAdminHostelTab() {
  const dateInput = document.getElementById('admin-hostel-date');
  if (dateInput && !dateInput.value) {
    const now = new Date();
    const y = now.getFullYear();
    const m = String(now.getMonth() + 1).padStart(2, '0');
    const d = String(now.getDate()).padStart(2, '0');
    dateInput.value = `${y}-${m}-${d}`;
  }
  loadAdminHostelSummary();
  loadAdminHostelMonthMatrix();
}

function setAdminHostelToday() {
  const dateInput = document.getElementById('admin-hostel-date');
  if (dateInput) {
    const now = new Date();
    const y = now.getFullYear();
    const m = String(now.getMonth() + 1).padStart(2, '0');
    const d = String(now.getDate()).padStart(2, '0');
    dateInput.value = `${y}-${m}-${d}`;
    loadAdminHostelSummary();
  }
}

function changeAdminHostelDate(delta) {
  const dateInput = document.getElementById('admin-hostel-date');
  if (!dateInput) return;
  const current = dateInput.value ? new Date(dateInput.value) : new Date();
  current.setDate(current.getDate() + delta);
  const y = current.getFullYear();
  const m = String(current.getMonth() + 1).padStart(2, '0');
  const d = String(current.getDate()).padStart(2, '0');
  dateInput.value = `${y}-${m}-${d}`;
  loadAdminHostelSummary();
}

async function loadAdminHostelSummary() {
  const dateInput = document.getElementById('admin-hostel-date');
  const targetDate = dateInput && dateInput.value ? dateInput.value : '';

  try {
    const res = await fetch(`/api/admin/hostel-meals/summary?date=${targetDate}`);
    const data = await res.json();

    if (data.success) {
      // Update KPIs
      const kpiTotal = document.getElementById('kpi-hostel-total');
      if (kpiTotal) kpiTotal.innerText = data.totalHostelers || 0;
      
      const b = data.headcount.breakfast;
      const bEating = document.getElementById('kpi-hostel-breakfast');
      const bSkipped = document.getElementById('kpi-hostel-breakfast-skipped');
      if (bEating) bEating.innerText = `${b.eating} Eating`;
      if (bSkipped) bSkipped.innerText = `${b.skipped} Skipped`;

      const l = data.headcount.lunch;
      const lEating = document.getElementById('kpi-hostel-lunch');
      const lSkipped = document.getElementById('kpi-hostel-lunch-skipped');
      if (lEating) lEating.innerText = `${l.eating} Eating`;
      if (lSkipped) lSkipped.innerText = `${l.skipped} Skipped`;

      const d = data.headcount.dinner;
      const dEating = document.getElementById('kpi-hostel-dinner');
      const dSkipped = document.getElementById('kpi-hostel-dinner-skipped');
      if (dEating) dEating.innerText = `${d.eating} Eating`;
      if (dSkipped) dSkipped.innerText = `${d.skipped} Skipped`;

      adminHostelRosterData = data.roster || [];
      renderAdminHostelRoster();
    }
  } catch (err) {
    console.error('Error fetching hostel summary:', err);
    showToast('Failed to load hostel data: ' + err.message, 'error');
  }
}

function filterAdminHostelRoster() {
  renderAdminHostelRoster();
}

function renderAdminHostelRoster() {
  const tbody = document.getElementById('admin-hostel-tbody');
  const countLabel = document.getElementById('admin-hostel-roster-count');
  if (!tbody) return;

  const searchQuery = (document.getElementById('admin-hostel-search')?.value || '').trim().toLowerCase();
  const filterVal = document.getElementById('admin-hostel-filter')?.value || 'ALL';

  let list = adminHostelRosterData.filter(item => {
    const matchesSearch = !searchQuery || 
      item.studentName.toLowerCase().includes(searchQuery) || 
      item.studentPhone.includes(searchQuery) ||
      item.studentId.includes(searchQuery);
    
    if (!matchesSearch) return false;

    if (filterVal === 'SKIPPING_ANY') return item.skippingAny;
    if (filterVal === 'EATING_ALL') return !item.skippingAny;
    if (filterVal === 'SKIPPING_BREAKFAST') return !item.breakfast;
    if (filterVal === 'SKIPPING_LUNCH') return !item.lunch;
    if (filterVal === 'SKIPPING_DINNER') return !item.dinner;

    return true;
  });

  if (countLabel) {
    countLabel.innerText = `Showing ${list.length} of ${adminHostelRosterData.length} hostelers`;
  }

  if (list.length === 0) {
    tbody.innerHTML = `<tr><td colspan="7" style="text-align: center; color: var(--text-dim); padding: 2.5rem;">No hostelers found matching your criteria.</td></tr>`;
    return;
  }

  tbody.innerHTML = list.map(student => {
    let summaryBadge = '';
    if (student.skippingAll) {
      summaryBadge = '<span class="badge badge-debit" style="font-size: 0.75rem;">Skipping All 3</span>';
    } else if (student.skippingAny) {
      summaryBadge = '<span class="badge badge-preparing" style="font-size: 0.75rem;">Skipping Some</span>';
    } else {
      summaryBadge = '<span class="badge badge-served" style="font-size: 0.75rem;">Eating All 3</span>';
    }

    return `
      <tr>
        <td>
          <div style="font-weight: 800; color: var(--text-main); font-size: 0.95rem;">${student.studentName}</div>
          <div style="font-size: 0.75rem; color: var(--text-dim);">${student.email}</div>
        </td>
        <td style="font-family: monospace; font-weight: 800; color: #38bdf8;">
          ${student.studentPhone}
        </td>
        <td>
          <button class="meal-toggle-btn ${student.breakfast ? 'btn-eating' : 'btn-skipped'}" onclick="adminToggleHostelMeal('${student.studentId}', '${student.date}', 'breakfast', ${student.breakfast})">
            ${student.breakfast ? '✅ Eating' : '❌ Skipped'}
          </button>
        </td>
        <td>
          <button class="meal-toggle-btn ${student.lunch ? 'btn-eating' : 'btn-skipped'}" onclick="adminToggleHostelMeal('${student.studentId}', '${student.date}', 'lunch', ${student.lunch})">
            ${student.lunch ? '✅ Eating' : '❌ Skipped'}
          </button>
        </td>
        <td>
          <button class="meal-toggle-btn ${student.dinner ? 'btn-eating' : 'btn-skipped'}" onclick="adminToggleHostelMeal('${student.studentId}', '${student.date}', 'dinner', ${student.dinner})">
            ${student.dinner ? '✅ Eating' : '❌ Skipped'}
          </button>
        </td>
        <td>${summaryBadge}</td>
        <td style="font-size: 0.78rem; color: var(--text-muted);">
          ${student.updatedAt ? new Date(student.updatedAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) : 'Default (YES)'}
        </td>
      </tr>
    `;
  }).join('');
}

async function adminToggleHostelMeal(studentId, date, meal, currentStatus) {
  const newStatus = !currentStatus;
  try {
    const res = await fetch('/api/student/meal-attendance/toggle', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        userId: studentId,
        date,
        meal,
        status: newStatus
      })
    });
    const data = await res.json();
    if (data.success) {
      showToast(`Updated ${meal} for student to ${newStatus ? 'Eating' : 'Skipped'}`, 'success');
      loadAdminHostelSummary();
    } else {
      showToast(data.message, 'error');
    }
  } catch (err) {
    showToast('Failed to update: ' + err.message, 'error');
  }
}

async function loadAdminHostelMonthMatrix() {
  const wrap = document.getElementById('admin-hostel-month-wrap');
  if (!wrap) return;

  wrap.innerHTML = '<div style="text-align: center; color: var(--text-muted); padding: 1.5rem;">Loading monthly forecast matrix...</div>';

  try {
    const res = await fetch('/api/admin/hostel-meals/month');
    const data = await res.json();

    if (!data.success) {
      wrap.innerHTML = `<div style="color: #f87171; text-align: center; padding: 1rem;">${data.message}</div>`;
      return;
    }

    const todayStr = new Date().toISOString().split('T')[0];

    const rowsHtml = data.dailyStats.map(d => {
      const isToday = d.date === todayStr;
      const bSkipped = d.totalHostelers - d.breakfast;
      const lSkipped = d.totalHostelers - d.lunch;
      const dSkipped = d.totalHostelers - d.dinner;

      return `
        <tr style="${isToday ? 'background: rgba(16, 185, 129, 0.08); font-weight: 700;' : ''}">
          <td>
            <strong>${d.date}</strong> ${isToday ? '<span class="badge badge-active" style="font-size: 0.68rem; margin-left: 0.35rem;">TODAY</span>' : ''}
          </td>
          <td>
            <span style="color: #34d399; font-weight: 800;">${d.breakfast}</span>
            <span style="color: var(--text-dim); font-size: 0.8rem;"> (${bSkipped} skip)</span>
          </td>
          <td>
            <span style="color: #34d399; font-weight: 800;">${d.lunch}</span>
            <span style="color: var(--text-dim); font-size: 0.8rem;"> (${lSkipped} skip)</span>
          </td>
          <td>
            <span style="color: #34d399; font-weight: 800;">${d.dinner}</span>
            <span style="color: var(--text-dim); font-size: 0.8rem;"> (${dSkipped} skip)</span>
          </td>
          <td style="color: #60a5fa; font-weight: 700;">${d.totalHostelers}</td>
        </tr>
      `;
    }).join('');

    wrap.innerHTML = `
      <table class="data-table" style="font-size: 0.88rem;">
        <thead>
          <tr>
            <th>Date (${data.targetMonth})</th>
            <th>🍳 Breakfast Headcount</th>
            <th>🍱 Lunch Headcount</th>
            <th>🍲 Dinner Headcount</th>
            <th>Total Hostelers</th>
          </tr>
        </thead>
        <tbody>
          ${rowsHtml}
        </tbody>
      </table>
    `;
  } catch (err) {
    wrap.innerHTML = `<div style="color: #f87171; text-align: center; padding: 1rem;">Failed to load matrix: ${err.message}</div>`;
  }
}
