Write-Host "=== VERIFYING NEW SPECIFICATIONS ==="

# 1. Page routes
$r1 = (Invoke-WebRequest -Uri "http://localhost:3000" -UseBasicParsing).StatusCode
$r2 = (Invoke-WebRequest -Uri "http://localhost:3000/student" -UseBasicParsing).StatusCode
$r3 = (Invoke-WebRequest -Uri "http://localhost:3000/admin" -UseBasicParsing).StatusCode
Write-Host "Routes accessible: Gateway ($r1), Student ($r2), Admin ($r3)"

# 2. Single Admin login with default password 'admin'
$adminLoginBody = '{"email":"admin@admin.com","password":"admin","role":"admin"}'
$adminRes = Invoke-RestMethod -Uri "http://localhost:3000/api/auth/login" -Method POST -Body $adminLoginBody -ContentType "application/json"
Write-Host "Admin Logged In: $($adminRes.user.email), mustChangePassword: $($adminRes.mustChangePassword)"

# 3. Admin Mandatory Password Change
$changeBody = '{"currentPassword":"admin","newPassword":"newpassword123"}'
$changeRes = Invoke-RestMethod -Uri "http://localhost:3000/api/admin/change-password" -Method POST -Body $changeBody -ContentType "application/json"
Write-Host "Admin Changed Password: $($changeRes.message)"

# 4. Re-login with new password
$adminReloginBody = '{"email":"admin@admin.com","password":"newpassword123","role":"admin"}'
$adminReloginRes = Invoke-RestMethod -Uri "http://localhost:3000/api/auth/login" -Method POST -Body $adminReloginBody -ContentType "application/json"
Write-Host "Admin Re-login with new password: mustChangePassword is $($adminReloginRes.mustChangePassword)"

# 5. Student Login with User ID (Phone: 9876543210)
$studentLoginBody = '{"email":"9876543210","password":"student123","role":"student"}'
$studentRes = Invoke-RestMethod -Uri "http://localhost:3000/api/auth/login" -Method POST -Body $studentLoginBody -ContentType "application/json"
$studentId = $studentRes.user.id
Write-Host "Student Logged In: $($studentRes.user.fullName), User ID (Phone): $studentId, Balance: $($studentRes.user.walletBalance)"

# 6. Admin Student Lookup
$lookupRes = Invoke-RestMethod -Uri "http://localhost:3000/api/admin/lookup-student?userId=$studentId" -Method GET
Write-Host "Cashier Lookup Verified: $($lookupRes.student.fullName), Balance: $($lookupRes.student.walletBalance)"

# 7. Admin Direct Wallet Credit by typing User ID
$creditObj = @{
    userId = $studentId
    amount = 200
    note = "Counter Cash 200 Deposit"
    adminEmail = "admin@admin.com"
}
$creditBody = $creditObj | ConvertTo-Json
$creditRes = Invoke-RestMethod -Uri "http://localhost:3000/api/admin/credit-wallet" -Method POST -Body $creditBody -ContentType "application/json"
Write-Host "Direct Wallet Credit Successful: New Balance: $($creditRes.newBalance) (Credited $($creditRes.creditedAmount))"

# 8. Student Pre-booking Order Creation
$orderObj = @{
    userId = $studentId
    items = @(
        @{ itemId = "ITEM-1"; quantity = 1 },
        @{ itemId = "ITEM-4"; quantity = 1 }
    )
}
$orderBody = $orderObj | ConvertTo-Json
$orderRes = Invoke-RestMethod -Uri "http://localhost:3000/api/orders/create" -Method POST -Body $orderBody -ContentType "application/json"
$orderId = $orderRes.order.id
Write-Host "Order Created: ID: $orderId, Total: $($orderRes.order.totalAmount), Balance After: $($orderRes.newBalance)"

# 9. Admin Counter QR Verification
$verifyObj = @{
    orderId = $orderId
    adminEmail = "admin@admin.com"
}
$verifyBody = $verifyObj | ConvertTo-Json
$verifyRes = Invoke-RestMethod -Uri "http://localhost:3000/api/canteen/verify-qr" -Method POST -Body $verifyBody -ContentType "application/json"
Write-Host "Counter QR Verification: Status: $($verifyRes.order.status)"

# 10. Duplicate Pickup Prevention
try {
    Invoke-RestMethod -Uri "http://localhost:3000/api/canteen/verify-qr" -Method POST -Body $verifyBody -ContentType "application/json"
    Write-Host "Duplicate pickup should fail"
} catch {
    Write-Host "Duplicate pickup correctly rejected with 409 Conflict: $($_.Exception.Message)"
}

# 11. Reset to seed
$resetRes = Invoke-RestMethod -Uri "http://localhost:3000/api/admin/reset" -Method POST
Write-Host "Database Reset to Fresh Seed: $($resetRes.message)"

Write-Host "=== ALL NEW REQUIREMENTS FULLY VERIFIED ==="
