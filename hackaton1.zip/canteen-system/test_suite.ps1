Write-Host "=== RUNNING CANTEEN SYSTEM TEST SUITE ==="

# 1. Test Static Routes
$p1 = (Invoke-WebRequest -Uri "http://localhost:3000" -UseBasicParsing).StatusCode
$p2 = (Invoke-WebRequest -Uri "http://localhost:3000/student" -UseBasicParsing).StatusCode
$p3 = (Invoke-WebRequest -Uri "http://localhost:3000/admin" -UseBasicParsing).StatusCode
Write-Host "Page Status Codes: / ($p1), /student ($p2), /admin ($p3)"

# 2. Test Menu
$menu = (Invoke-RestMethod -Uri "http://localhost:3000/api/menu").menu
Write-Host "Menu items count: $($menu.Count)"

# 3. Test Student Login
$bodyLogin = '{"email":"student@canteen.local","password":"student123"}'
$loginRes = Invoke-RestMethod -Uri "http://localhost:3000/api/auth/login" -Method POST -Body $bodyLogin -ContentType "application/json"
$studentId = $loginRes.user.id
Write-Host "Student logged in: $($loginRes.user.fullName), ID: $studentId, Balance: $($loginRes.user.walletBalance)"

# 4. Test Key Redemption (OFFICE100)
$bodyRedeem = "{`"key`":`"OFFICE100`",`"userId`":`"$studentId`"}"
$redeemRes = Invoke-RestMethod -Uri "http://localhost:3000/api/wallet/redeem" -Method POST -Body $bodyRedeem -ContentType "application/json"
Write-Host "OFFICE100 Redeemed: Balance is now $($redeemRes.newBalance)"

# 5. Test Double Redemption Prevention
try {
    Invoke-RestMethod -Uri "http://localhost:3000/api/wallet/redeem" -Method POST -Body $bodyRedeem -ContentType "application/json"
    Write-Host "Double redemption should have failed"
} catch {
    Write-Host "Duplicate Key Redemption correctly blocked by server: $($_.Exception.Message)"
}

# 6. Test Food Order Pre-booking
$bodyOrder = "{`"userId`":`"$studentId`",`"items`":[{`"itemId`":`"ITEM-1`",`"quantity`":1},{`"itemId`":`"ITEM-4`",`"quantity`":2}]}"
$orderRes = Invoke-RestMethod -Uri "http://localhost:3000/api/orders/create" -Method POST -Body $bodyOrder -ContentType "application/json"
$orderId = $orderRes.order.id
Write-Host "Order Created: $orderId, Total: $($orderRes.order.totalAmount), New Balance: $($orderRes.newBalance)"

# 7. Test Admin Key Generation
$bodyKeyGen = '{"amount":200,"adminId":"USR-ADM"}'
$keyRes = Invoke-RestMethod -Uri "http://localhost:3000/api/admin/generate-key" -Method POST -Body $bodyKeyGen -ContentType "application/json"
Write-Host "Admin Generated Key: $($keyRes.key.code) for Amount $($keyRes.key.amount)"

# 8. Test QR Code / Order ID Verification at Canteen Counter
$bodyVerify = "{`"orderId`":`"$orderId`",`"adminId`":`"USR-ADM`"}"
$verifyRes = Invoke-RestMethod -Uri "http://localhost:3000/api/canteen/verify-qr" -Method POST -Body $bodyVerify -ContentType "application/json"
Write-Host "QR Verification: Status is now '$($verifyRes.order.status)' at $($verifyRes.order.servedAt)"

# 9. Test Duplicate Pickup Prevention
try {
    Invoke-RestMethod -Uri "http://localhost:3000/api/canteen/verify-qr" -Method POST -Body $bodyVerify -ContentType "application/json"
    Write-Host "Duplicate pickup should have failed"
} catch {
    Write-Host "Duplicate Pickup correctly blocked by server: $($_.Exception.Message)"
}

# 10. Test Transactions Ledger
$txns = (Invoke-RestMethod -Uri "http://localhost:3000/api/transactions?userId=$studentId").transactions
Write-Host "Student Transactions count: $($txns.Count)"

Write-Host "=== ALL TESTS COMPLETED SUCCESSFULLY ==="
