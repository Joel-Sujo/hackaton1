# MITSgrub — Campus Pre-booking, Direct Wallet & Cashier POS System

A modern full-stack, browser-accessible web application designed for campus canteens to eliminate food pickup queues and simplify cash-to-digital wallet operations.

Runs **100% offline on `localhost` and local Wi-Fi** with **zero paid third-party APIs or external dependencies**.

---

## 🚀 Browser Access URLs

The server runs on **`localhost:3000`** and is bound to all network interfaces (`0.0.0.0`):

- **System Gateway:** [http://localhost:3000](http://localhost:3000)
- **MITSgrub Student Web App:** [http://localhost:3000/student](http://localhost:3000/student) *(Mobile & laptop dark theme)*
- **MITSgrub Admin POS Terminal:** [http://localhost:3000/admin](http://localhost:3000/admin) *(Operations & cashier terminal)*
- **Wi-Fi Network Access (Phones on Same Wi-Fi):** `http://192.168.1.240:3000/student`

---

## 🍽️ New Features in MITSgrub

### 1. Pre-Registered Student Demo Removed
- Students register their real account with their **Full Name, 10-digit Phone Number (permanent User ID), Email, and Password**.
- The pre-registered demo login shortcut and hardcoded values have been removed.

### 2. Admin Menu Manager (Add Dishes, Snacks & Drinks)
- In the Admin POS (`/admin`), go to **"🍽️ Menu & Inventory"**.
- Click **"➕ Add New Menu Item"**:
  - **Item Name:** e.g. *Chicken Dum Biryani*, *Mango Lassi*, *Paneer Frankie Roll*
  - **Category:** Select *Dishes / Meals*, *Snacks*, *Drinks / Beverages*, *South Indian*, *Fast Food*, or *Desserts*
  - **Price in ₹:** Set item price
  - **Initial Stock Count:** Portions available
  - **Food Icon/Emoji:** Select from preset chips (🍛, 🥪, 🥤, 🍕, ☕, 🍱, 🥟, 🍔, 🍜, 🥞, 🌯, 🍦)
  - **Badge Tag:** e.g. *Popular*, *Chef Special*, *Chilled*, *Spicy*, *Fresh*
  - **Description:** Optional details
- **Instant Real-Time Sync:** When an item is added, it immediately reflects across all student screens and mobile devices via automatic background polling!

### 3. Delete Menu Items
- In the Admin Menu table, click **"🗑️ Delete"** on any item.
- Confirms removal and immediately takes it off the menu. If a student has it in their cart, the cart cleans it up automatically.

### 4. Adjust Stock Left in Real Time
- Quick `+10`, `+25`, or custom `Set` stock buttons.
- Real-time stock status badges (`In Stock`, `Low Stock`, `Out of Stock`) update instantly on student phones.

### 5. Direct Cashier Wallet Credit
- Cashier enters the student's **User ID (Phone Number)**.
- Live lookup verifies student name and current balance.
- Select cash amount (₹50, ₹100, ₹200, ₹500, ₹1000) and click **"⚡ Credit Wallet Directly"**.
- Real-time balance updates on the student's phone.

### 6. Single Admin Account
- **Email:** `admin@admin.com`
- **Default Password:** `admin`
- Required to set a new password on first login before accessing the console.

---

## 🔌 REST API Endpoints

| Method | Endpoint | Description |
|---|---|---|
| `POST` | `/api/admin/menu/add` | Adds new dish, snack, or drink with price & stock |
| `POST` | `/api/admin/menu/delete` | Removes an item from the menu |
| `POST` | `/api/admin/menu/update-stock` | Replenishes portion counts |
| `GET` | `/api/menu` | Fetches active menu items with live stock |
| `POST` | `/api/admin/credit-wallet` | Cashier credits cash directly to student User ID |
| `GET` | `/api/admin/lookup-student` | Instant cashier lookup by User ID (Phone) |
| `POST` | `/api/auth/register` | Student registration with Phone as User ID |
| `POST` | `/api/auth/login` | Student or Admin authentication |
| `POST` | `/api/admin/change-password` | Mandatory admin password change |
| `POST` | `/api/orders/create` | Deducts wallet balance, creates order & generates QR |
| `POST` | `/api/canteen/verify-qr` | Counter QR/Order ID verification & duplicate pickup prevention |
| `GET` | `/api/transactions` | Passbook statements ledger |
| `GET` | `/api/admin/orders` | Kitchen queue orders with status filtering |
| `POST` | `/api/admin/orders/:id/status` | Advances order preparation status |
| `GET` | `/api/system/network-info` | Returns local LAN IP and mobile QR code |
| `POST` | `/api/admin/reset` | Resets database to seed data |
