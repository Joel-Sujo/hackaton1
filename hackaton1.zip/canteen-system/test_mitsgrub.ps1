Write-Host "=== TESTING MITSgrub NEW CAPABILITIES ==="

# 1. Check MITSgrub Branding in HTML
$htmlStudent = (Invoke-WebRequest -Uri "http://localhost:3000/student" -UseBasicParsing).Content
$hasMits = $htmlStudent -match "MITSgrub"
$hasNoDemo = ($htmlStudent -notmatch "Quick 1-Click Demo Login") -and ($htmlStudent -notmatch "Rahul Sharma \(User ID: 9876543210\)")
Write-Host "MITSgrub branding present: $hasMits, Pre-registered student button removed: $hasNoDemo"

# 2. Admin adds a Dish
$dishObj = @{
    name = "Chicken Dum Biryani"
    category = "Dishes / Meals"
    price = 140
    stock = 25
    icon = "🍛"
    badge = "Chef Special"
    description = "Aromatic basmati rice cooked with tender spiced chicken pieces and saffron."
}
$dishRes = Invoke-RestMethod -Uri "http://localhost:3000/api/admin/menu/add" -Method POST -Body ($dishObj | ConvertTo-Json) -ContentType "application/json"
$dishId = $dishRes.item.id
Write-Host "Admin added Dish: $($dishRes.item.name) (ID: $dishId, Price: ₹$($dishRes.item.price), Stock: $($dishRes.item.stock))"

# 3. Admin adds a Drink
$drinkObj = @{
    name = "Mango Thick Lassi"
    category = "Drinks / Beverages"
    price = 50
    stock = 30
    icon = "🥤"
    badge = "Chilled"
    description = "Rich yogurt smoothie blended with sweet Alphonso mango pulp."
}
$drinkRes = Invoke-RestMethod -Uri "http://localhost:3000/api/admin/menu/add" -Method POST -Body ($drinkObj | ConvertTo-Json) -ContentType "application/json"
$drinkId = $drinkRes.item.id
Write-Host "Admin added Drink: $($drinkRes.item.name) (ID: $drinkId, Price: ₹$($drinkRes.item.price), Stock: $($drinkRes.item.stock))"

# 4. Admin adds a Snack
$snackObj = @{
    name = "Cheesy Peri-Peri Fries"
    category = "Snacks"
    price = 75
    stock = 40
    icon = "🍟"
    badge = "Crispy"
    description = "Golden crisp potato fries tossed in spicy peri-peri dust and melted cheese."
}
$snackRes = Invoke-RestMethod -Uri "http://localhost:3000/api/admin/menu/add" -Method POST -Body ($snackObj | ConvertTo-Json) -ContentType "application/json"
$snackId = $snackRes.item.id
Write-Host "Admin added Snack: $($snackRes.item.name) (ID: $snackId, Price: ₹$($snackRes.item.price), Stock: $($snackRes.item.stock))"

# 5. Real-time Menu Verification
$menu = (Invoke-RestMethod -Uri "http://localhost:3000/api/menu").menu
Write-Host "Live Menu count: $($menu.Count) items"

# 6. Student Registration & Pre-booking of the newly added item
$regObj = @{
    fullName = "Ananya Sen"
    phone = "9811223344"
    email = "ananya@mits.edu"
    password = "password123"
}
$regRes = Invoke-RestMethod -Uri "http://localhost:3000/api/auth/register" -Method POST -Body ($regObj | ConvertTo-Json) -ContentType "application/json"
$studentId = $regRes.user.id
Write-Host "New Student Registered: $($regRes.user.fullName), User ID: $studentId"

# Cashier directly credits Ananya's wallet
$creditObj = @{
    userId = $studentId
    amount = 300
    note = "Cash Deposit for Lunch"
    adminEmail = "admin@admin.com"
}
$creditRes = Invoke-RestMethod -Uri "http://localhost:3000/api/admin/credit-wallet" -Method POST -Body ($creditObj | ConvertTo-Json) -ContentType "application/json"
Write-Host "Cashier Credited Ananya's Wallet: ₹$($creditRes.newBalance)"

# Ananya pre-books the new Biryani and Mango Lassi
$orderObj = @{
    userId = $studentId
    items = @(
        @{ itemId = $dishId; quantity = 1 },
        @{ itemId = $drinkId; quantity = 1 }
    )
}
$orderRes = Invoke-RestMethod -Uri "http://localhost:3000/api/orders/create" -Method POST -Body ($orderObj | ConvertTo-Json) -ContentType "application/json"
Write-Host "Order Created for new items: Total ₹$($orderRes.order.totalAmount), Remaining Balance: ₹$($orderRes.newBalance)"

# 7. Admin deletes the Snack
$delObj = @{ itemId = $snackId }
$delRes = Invoke-RestMethod -Uri "http://localhost:3000/api/admin/menu/delete" -Method POST -Body ($delObj | ConvertTo-Json) -ContentType "application/json"
Write-Host "Admin deleted item: $($delRes.message)"

# 8. Verify item is removed from live menu
$menuAfter = (Invoke-RestMethod -Uri "http://localhost:3000/api/menu").menu
$stillExists = ($menuAfter | Where-Object { $_.id -eq $snackId })
if ($null -eq $stillExists) {
    Write-Host "Confirmed: Deleted item is no longer in the MITSgrub menu!"
} else {
    Write-Error "Item still exists after delete!"
}

Write-Host "=== ALL MITSgrub TESTS PASSED WITH 100% SUCCESS ==="
